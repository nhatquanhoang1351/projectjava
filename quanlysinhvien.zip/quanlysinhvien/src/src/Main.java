package src;

import view.ManHinhChinh;
import view.QuanLyKhoaPanel;
import view.QuanLyLopHocPhanPanel;
import view.QuanLySinhVienPanel;
import view.QuanLyMonHocPanel;
import view.QuanLyDiemPanel;
import view.QuanLyGiangVienPanel;
import view.QuanLyDangKyHocPhanPanel;
import controller.QuanLyKhoaController;
import controller.QuanLyGiangVienController;
import controller.QuanLyLopHocPhanController;
import controller.QuanLySinhVienController;
import controller.QuanLyMonHocController;
import controller.QuanLyDiemController;
import controller.QuanLyDangKyHocPhanController;
import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            ManHinhChinh mainFrame = new ManHinhChinh();
            mainFrame.setTitle("Quản Lý Sinh Viên");
            mainFrame.setSize(1200, 800);
            mainFrame.setLocationRelativeTo(null);
            mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            QuanLyKhoaPanel khoaPanel = new QuanLyKhoaPanel();
            QuanLyLopHocPhanPanel lopPanel = new QuanLyLopHocPhanPanel();
            QuanLySinhVienPanel sinhVienPanel = new QuanLySinhVienPanel();
            QuanLyMonHocPanel monHocPanel = new QuanLyMonHocPanel();
            QuanLyDiemPanel diemPanel = new QuanLyDiemPanel();
            QuanLyGiangVienPanel giangVienPanel = new QuanLyGiangVienPanel();
            QuanLyDangKyHocPhanPanel hocPhanPanel = new QuanLyDangKyHocPhanPanel();

            new QuanLyKhoaController(khoaPanel);
            new QuanLyLopHocPhanController(lopPanel);
            new QuanLySinhVienController(sinhVienPanel);
            new QuanLyMonHocController(monHocPanel);
            new QuanLyDiemController(diemPanel);
            new QuanLyGiangVienController(giangVienPanel);
            new QuanLyDangKyHocPhanController(hocPhanPanel);

            JPanel contentPanel = new JPanel(new CardLayout());
            contentPanel.add(khoaPanel, "Khoa");
            contentPanel.add(lopPanel, "Lop");
            contentPanel.add(sinhVienPanel, "SinhVien");
            contentPanel.add(monHocPanel, "MonHoc");
            contentPanel.add(diemPanel, "Diem");
            contentPanel.add(giangVienPanel, "GiangVien");
            contentPanel.add(hocPhanPanel, "HocPhan");

            mainFrame.add(contentPanel);

            mainFrame.getBtnKhoa().addActionListener(e -> {
                CardLayout cl = (CardLayout) contentPanel.getLayout();
                cl.show(contentPanel, "Khoa");
            });

            mainFrame.getBtnLop().addActionListener(e -> {
                CardLayout cl = (CardLayout) contentPanel.getLayout();
                cl.show(contentPanel, "Lop");
            });

            mainFrame.getBtnSinhVien().addActionListener(e -> {
                CardLayout cl = (CardLayout) contentPanel.getLayout();
                cl.show(contentPanel, "SinhVien");
            });

            mainFrame.getBtnMonHoc().addActionListener(e -> {
                CardLayout cl = (CardLayout) contentPanel.getLayout();
                cl.show(contentPanel, "MonHoc");
            });

            mainFrame.getBtnDiem().addActionListener(e -> {
                CardLayout cl = (CardLayout) contentPanel.getLayout();
                cl.show(contentPanel, "Diem");
            });
            
            mainFrame.getBtnGiangVien().addActionListener(e -> {
                CardLayout cl = (CardLayout) contentPanel.getLayout();
                cl.show(contentPanel, "GiangVien");
            });

            mainFrame.getBtnDangKyLop().addActionListener(e -> {
                CardLayout cl = (CardLayout) contentPanel.getLayout();
                cl.show(contentPanel, "HocPhan");
            });
            
            mainFrame.setVisible(true);
        });
    }
} 