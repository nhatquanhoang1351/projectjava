/**
 * 
 */
/**
 * 
 */
module quanlysinhvien {
    requires java.sql;
    requires java.desktop;
    requires java.base;
    
    exports src;
//    exports src.view;
//    exports src.controller;
//    exports src.model;
}