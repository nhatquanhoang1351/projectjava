package controller;

import model.SinhVien;
import dao.SinhVienDAO;
import view.QuanLySinhVienPanel;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class QuanLySinhVienController {
    private QuanLySinhVienPanel view;
    private SinhVienDAO sinhVienDAO;
    private SimpleDateFormat dateFormat;
    private SimpleDateFormat dbDateFormat;

    public QuanLySinhVienController(QuanLySinhVienPanel view) {
        this.view = view;
        this.sinhVienDAO = new SinhVienDAO();
        this.dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        this.dbDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        initController();
        loadData();
    }

    private void initController() {
        view.themSuKienThem(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                themSinhVien();
            }
        });

        view.themSuKienSua(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                suaSinhVien();
            }
        });

        view.themSuKienXoa(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xoaSinhVien();
            }
        });

        view.themSuKienLamMoi(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadData();
                view.lamMoiForm();
            }
        });

        view.themSuKienTimKiem(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timKiemSinhVien();
            }
        });

        view.themSuKienChonDong(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = view.getTblSinhVien().getSelectedRow();
                    if (selectedRow != -1) {
                        hienThiSinhVienDuocChon(selectedRow);
                    }
                }
            }
        });
    }

    private void loadData() {
        DefaultTableModel model = view.getModelSinhVien();
        model.setRowCount(0);
        List<SinhVien> danhSach = sinhVienDAO.layTatCaSinhVien();
        for (SinhVien sv : danhSach) {
            String ngaySinhHienThi = "";
            if (sv.getNgaySinh() != null && !sv.getNgaySinh().isEmpty()) {
                try {
                    java.util.Date ngaySinh = dbDateFormat.parse(sv.getNgaySinh());
                    ngaySinhHienThi = dateFormat.format(ngaySinh);
                } catch (ParseException ex) {
                    ngaySinhHienThi = sv.getNgaySinh();
                }
            }

            model.addRow(new Object[]{
                sv.getMaSinhVien(),
                sv.getMaSo() != null ? sv.getMaSo() : "",
                sv.getHoTen(),
                ngaySinhHienThi,
                sv.getGioiTinh() != null ? sv.getGioiTinh() : "",
                sv.getDiaChi() != null ? sv.getDiaChi() : "",
                sv.getSoDienThoai() != null ? sv.getSoDienThoai() : "",
                sv.getEmail() != null ? sv.getEmail() : ""
            });
        }
    }

    private void themSinhVien() {
        String maSo = view.getTxtMaSo().getText().trim();
        String hoTen = view.getTxtHoTen().getText().trim();
        String ngaySinhStr = view.getTxtNgaySinh().getText().trim();
        String gioiTinh = view.getCboGioiTinh().getSelectedItem().toString();
        String diaChi = view.getTxtDiaChi().getText().trim();
        String soDienThoai = view.getTxtSoDienThoai().getText().trim();
        String email = view.getTxtEmail().getText().trim();

        if (maSo.isEmpty() || hoTen.isEmpty() || ngaySinhStr.isEmpty() || 
            diaChi.isEmpty() || soDienThoai.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Vui lòng nhập đầy đủ thông tin!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            java.util.Date ngaySinh = dateFormat.parse(ngaySinhStr);
            String ngaySinhDB = dbDateFormat.format(ngaySinh);

            SinhVien sv = new SinhVien();
            sv.setMaSo(maSo);
            sv.setHoTen(hoTen);
            sv.setMaLop(1); // Giá trị mặc định cho ma_lop
            sv.setNgaySinh(ngaySinhDB);
            sv.setGioiTinh(gioiTinh);
            sv.setDiaChi(diaChi);
            sv.setSoDienThoai(soDienThoai);
            sv.setEmail(email);

            if (sinhVienDAO.themSinhVien(sv)) {
                JOptionPane.showMessageDialog(view, "Thêm sinh viên thành công!");
                loadData();
                view.lamMoiForm();
            } else {
                JOptionPane.showMessageDialog(view, "Thêm sinh viên thất bại! Kiểm tra thông tin nhập.");
            }
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(view, "Định dạng ngày sinh không hợp lệ (dd/MM/yyyy)!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void suaSinhVien() {
        String maSinhVienStr = view.getTxtMaSinhVien().getText().trim();
        String maSo = view.getTxtMaSo().getText().trim();
        String hoTen = view.getTxtHoTen().getText().trim();
        String ngaySinhStr = view.getTxtNgaySinh().getText().trim();
        String gioiTinh = view.getCboGioiTinh().getSelectedItem().toString();
        String diaChi = view.getTxtDiaChi().getText().trim();
        String soDienThoai = view.getTxtSoDienThoai().getText().trim();
        String email = view.getTxtEmail().getText().trim();

        if (maSinhVienStr.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Vui lòng chọn sinh viên cần sửa!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (maSo.isEmpty() || hoTen.isEmpty() || ngaySinhStr.isEmpty() || 
            diaChi.isEmpty() || soDienThoai.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Vui lòng nhập đầy đủ thông tin!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            java.util.Date ngaySinh = dateFormat.parse(ngaySinhStr);
            String ngaySinhDB = dbDateFormat.format(ngaySinh);

            int maSinhVien = Integer.parseInt(maSinhVienStr);

            SinhVien sv = new SinhVien();
            sv.setMaSinhVien(maSinhVien);
            sv.setMaSo(maSo);
            sv.setHoTen(hoTen);
            sv.setMaLop(1); // Giá trị mặc định cho ma_lop
            sv.setNgaySinh(ngaySinhDB);
            sv.setGioiTinh(gioiTinh);
            sv.setDiaChi(diaChi);
            sv.setSoDienThoai(soDienThoai);
            sv.setEmail(email);

            if (sinhVienDAO.capNhatSinhVien(sv)) {
                JOptionPane.showMessageDialog(view, "Cập nhật sinh viên thành công!");
                loadData();
                view.lamMoiForm();
            } else {
                JOptionPane.showMessageDialog(view, "Cập nhật sinh viên thất bại! Kiểm tra thông tin nhập.");
            }
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(view, "Định dạng ngày sinh không hợp lệ (dd/MM/yyyy)!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(view, "Mã sinh viên không hợp lệ!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xoaSinhVien() {
        String maSinhVienStr = view.getTxtMaSinhVien().getText().trim();

        if (maSinhVienStr.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Vui lòng chọn sinh viên cần xóa!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(view, 
                "Bạn có chắc chắn muốn xóa sinh viên này?", 
                "Xác nhận xóa", 
                JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                int maSinhVien = Integer.parseInt(maSinhVienStr);
                if (sinhVienDAO.xoaSinhVien(maSinhVien)) {
                    JOptionPane.showMessageDialog(view, "Xóa sinh viên thành công!");
                    loadData();
                    view.lamMoiForm();
                } else {
                    JOptionPane.showMessageDialog(view, "Xóa sinh viên thất bại!");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(view, "Mã sinh viên không hợp lệ!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void timKiemSinhVien() {
        String tuKhoa = view.getTxtSearch().getText().trim();
        if (tuKhoa.isEmpty()) {
            loadData();
            return;
        }

        DefaultTableModel model = view.getModelSinhVien();
        model.setRowCount(0);
        List<SinhVien> danhSach = sinhVienDAO.timSinhVienTheoTen(tuKhoa);
        for (SinhVien sv : danhSach) {
            String ngaySinhHienThi = "";
            if (sv.getNgaySinh() != null && !sv.getNgaySinh().isEmpty()) {
                try {
                    java.util.Date ngaySinh = dbDateFormat.parse(sv.getNgaySinh());
                    ngaySinhHienThi = dateFormat.format(ngaySinh);
                } catch (ParseException ex) {
                    ngaySinhHienThi = sv.getNgaySinh();
                }
            }

            model.addRow(new Object[]{
                sv.getMaSinhVien(),
                sv.getMaSo() != null ? sv.getMaSo() : "",
                sv.getHoTen(),
                ngaySinhHienThi,
                sv.getGioiTinh() != null ? sv.getGioiTinh() : "",
                sv.getDiaChi() != null ? sv.getDiaChi() : "",
                sv.getSoDienThoai() != null ? sv.getSoDienThoai() : "",
                sv.getEmail() != null ? sv.getEmail() : ""
            });
        }
    }

    private void hienThiSinhVienDuocChon(int row) {
        DefaultTableModel model = view.getModelSinhVien();
        view.getTxtMaSinhVien().setText(model.getValueAt(row, 0).toString());
        view.getTxtMaSo().setText(model.getValueAt(row, 1).toString());
        view.getTxtHoTen().setText(model.getValueAt(row, 2).toString());
        view.getTxtNgaySinh().setText(model.getValueAt(row, 3).toString());
        view.getCboGioiTinh().setSelectedItem(model.getValueAt(row, 4).toString());
        view.getTxtDiaChi().setText(model.getValueAt(row, 5).toString());
        view.getTxtSoDienThoai().setText(model.getValueAt(row, 6).toString());
        view.getTxtEmail().setText(model.getValueAt(row, 7).toString());
    }
}