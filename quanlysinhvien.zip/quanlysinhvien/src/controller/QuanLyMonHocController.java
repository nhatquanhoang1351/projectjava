package controller;

import view.QuanLyMonHocPanel;
import dao.MonHocDAO;
import dao.KhoaDAO;
import model.MonHoc;
import model.Khoa;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuanLyMonHocController {
    private QuanLyMonHocPanel view;
    private MonHocDAO monHocDAO;
    private KhoaDAO khoaDAO;
    private Map<String, Integer> khoaMap; 

    public QuanLyMonHocController(QuanLyMonHocPanel view) {
        this.view = view;
        this.monHocDAO = new MonHocDAO();
        this.khoaDAO = new KhoaDAO();
        initController();
        loadComboBoxKhoa();
        loadData();
    }

    private void initController() {
        view.themSuKienThem(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                themMonHoc();
            }
        });

        view.themSuKienSua(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                suaMonHoc();
            }
        });

        view.themSuKienXoa(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xoaMonHoc();
            }
        });

        view.themSuKienLamMoi(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadData();
                view.lamMoiForm();
            }
        });

        view.themSuKienChonDong(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = view.getTblMonHoc().getSelectedRow();
                    if (selectedRow != -1) {
                        hienThiMonHocDuocChon(selectedRow);
                    }
                }
            }
        });

        view.themSuKienTimKiem(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timKiemMonHoc();
            }
        });
    }

    private void loadData() {
        try {
            List<MonHoc> danhSachMonHoc = monHocDAO.layTatCaMonHoc();
            DefaultTableModel model = view.getModelMonHoc();
            model.setRowCount(0);
            
            for (MonHoc mh : danhSachMonHoc) {
                String tenKhoa = layTenKhoaTheoMa(mh.getMaKhoa());
                model.addRow(new Object[]{
                    mh.getMaMonHoc(),
                    mh.getTenMonHoc(),
                    mh.getSoTinChi(),
                    tenKhoa
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi tải dữ liệu: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadComboBoxKhoa() {
        try {
            List<Khoa> danhSachKhoa = khoaDAO.layTatCaKhoa();
            JComboBox<String> cboKhoa = view.getCboKhoa();
            cboKhoa.removeAllItems();
            
            khoaMap = new HashMap<>();
            for (Khoa khoa : danhSachKhoa) {
                cboKhoa.addItem(khoa.getTenKhoa());
                khoaMap.put(khoa.getTenKhoa(), khoa.getMaKhoa());
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi tải danh sách khoa: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void themMonHoc() {
        String maMonHoc = view.getTxtMaMonHoc().getText().trim();
        String tenMonHoc = view.getTxtTenMonHoc().getText().trim();
        String soTinChiStr = view.getTxtSoTinChi().getText().trim();
        String tenKhoa = (String) view.getCboKhoa().getSelectedItem();

        if (maMonHoc.isEmpty() || tenMonHoc.isEmpty() || soTinChiStr.isEmpty() || tenKhoa == null) {
            JOptionPane.showMessageDialog(view, "Vui lòng nhập đầy đủ thông tin!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int soTinChi = Integer.parseInt(soTinChiStr);
            if (soTinChi <= 0) {
                JOptionPane.showMessageDialog(view, "Số tín chỉ phải lớn hơn 0!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (monHocDAO.timMonHocTheoMa(maMonHoc) != null) {
                JOptionPane.showMessageDialog(view, "Mã môn học đã tồn tại!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int maKhoa = khoaMap.get(tenKhoa);
            MonHoc monHoc = new MonHoc(maMonHoc, tenMonHoc, soTinChi, maKhoa);
            
            if (monHocDAO.themMonHoc(monHoc)) {
                JOptionPane.showMessageDialog(view, "Thêm môn học thành công!");
                loadData();
                view.lamMoiForm();
            } else {
                JOptionPane.showMessageDialog(view, "Thêm môn học thất bại!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(view, "Số tín chỉ phải là số!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi thêm môn học: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void suaMonHoc() {
        String maMonHoc = view.getTxtMaMonHoc().getText().trim();
        String tenMonHoc = view.getTxtTenMonHoc().getText().trim();
        String soTinChiStr = view.getTxtSoTinChi().getText().trim();
        String tenKhoa = (String) view.getCboKhoa().getSelectedItem();

        if (maMonHoc.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Vui lòng chọn môn học cần sửa!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (tenMonHoc.isEmpty() || soTinChiStr.isEmpty() || tenKhoa == null) {
            JOptionPane.showMessageDialog(view, "Vui lòng nhập đầy đủ thông tin!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int soTinChi = Integer.parseInt(soTinChiStr);
            if (soTinChi <= 0) {
                JOptionPane.showMessageDialog(view, "Số tín chỉ phải lớn hơn 0!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int maKhoa = khoaMap.get(tenKhoa);
            MonHoc monHoc = new MonHoc(maMonHoc, tenMonHoc, soTinChi, maKhoa);
            
            if (monHocDAO.capNhatMonHoc(monHoc)) {
                JOptionPane.showMessageDialog(view, "Cập nhật môn học thành công!");
                loadData();
                view.lamMoiForm();
            } else {
                JOptionPane.showMessageDialog(view, "Cập nhật môn học thất bại!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(view, "Số tín chỉ phải là số!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi cập nhật môn học: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xoaMonHoc() {
        String maMonHoc = view.getTxtMaMonHoc().getText().trim();

        if (maMonHoc.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Vui lòng chọn môn học cần xóa!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(view, 
                "Bạn có chắc chắn muốn xóa môn học này?", 
                "Xác nhận xóa", 
                JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                if (monHocDAO.xoaMonHoc(maMonHoc)) {
                    JOptionPane.showMessageDialog(view, "Xóa môn học thành công!");
                    loadData();
                    view.lamMoiForm();
                } else {
                    JOptionPane.showMessageDialog(view, "Xóa môn học thất bại!", 
                            "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(view, "Lỗi khi xóa môn học: " + ex.getMessage(),
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void timKiemMonHoc() {
        String tuKhoa = view.getTxtSearch().getText().trim();
        try {
            DefaultTableModel model = view.getModelMonHoc();
            model.setRowCount(0);
            
            List<MonHoc> danhSachMonHoc;
            if (tuKhoa.isEmpty()) {
                danhSachMonHoc = monHocDAO.layTatCaMonHoc();
            } else {
                danhSachMonHoc = monHocDAO.timMonHocTheoTen(tuKhoa);
            }
            
            for (MonHoc mh : danhSachMonHoc) {
                String tenKhoa = layTenKhoaTheoMa(mh.getMaKhoa());
                model.addRow(new Object[]{
                    mh.getMaMonHoc(),
                    mh.getTenMonHoc(),
                    mh.getSoTinChi(),
                    tenKhoa
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi tìm kiếm: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void hienThiMonHocDuocChon(int row) {
        DefaultTableModel model = view.getModelMonHoc();
        String maMonHoc = model.getValueAt(row, 0).toString();
        
        MonHoc monHoc = monHocDAO.timMonHocTheoMa(maMonHoc);
        if (monHoc != null) {
            view.getTxtMaMonHoc().setText(monHoc.getMaMonHoc());
            view.getTxtTenMonHoc().setText(monHoc.getTenMonHoc());
            view.getTxtSoTinChi().setText(String.valueOf(monHoc.getSoTinChi()));
            
            String tenKhoa = layTenKhoaTheoMa(monHoc.getMaKhoa());
            view.getCboKhoa().setSelectedItem(tenKhoa);
        }
    }

    private String layTenKhoaTheoMa(int maKhoa) {
        for (Map.Entry<String, Integer> entry : khoaMap.entrySet()) {
            if (entry.getValue().equals(maKhoa)) {
                return entry.getKey();
            }
        }
        return "Không xác định";
    }
}