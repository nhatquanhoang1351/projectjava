package controller;

import dao.KhoaDAO;
import model.Khoa;
import view.QuanLyKhoaPanel;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class QuanLyKhoaController {
    private QuanLyKhoaPanel view;
    private KhoaDAO khoaDAO;

    public QuanLyKhoaController(QuanLyKhoaPanel view) {
        this.view = view;
        this.khoaDAO = new KhoaDAO();
        initController();
        loadData();
    }

    private void initController() {
        view.themSuKienThem(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                themKhoa();
            }
        });

        view.themSuKienSua(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                suaKhoa();
            }
        });

        view.themSuKienXoa(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xoaKhoa();
            }
        });

        view.themSuKienLamMoi(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadData();
                view.lamMoiForm();
            }
        });

        view.themSuKienTimKiem(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tenKhoa = view.getTxtTimKiem().getText().trim();
                timKiemKhoa(tenKhoa);
            }
        });

        view.themSuKienChonDong(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = view.getTblKhoa().getSelectedRow();
                    if (selectedRow != -1) {
                        int modelRow = view.getTblKhoa().convertRowIndexToModel(selectedRow);
                        hienThiKhoaDuocChon(modelRow);
                    }
                }
            }
        });
    }

    private void loadData() {
        try {
            DefaultTableModel model = view.getModelKhoa();
            model.setRowCount(0);
            
            List<Khoa> danhSachKhoa = khoaDAO.layTatCaKhoa();
            for (Khoa khoa : danhSachKhoa) {
                model.addRow(new Object[]{
                    khoa.getMaKhoa(),
                    khoa.getTenKhoa(),
                    khoa.getMoTa()
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi tải dữ liệu: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void themKhoa() {
        String tenKhoa = view.getTxtTenKhoa().getText().trim();
        String moTa = view.getTxtMoTa() != null ? view.getTxtMoTa().getText().trim() : "";

        if (tenKhoa.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Vui lòng nhập tên khoa!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            view.getTxtTenKhoa().requestFocus();
            return;
        }

        try {
            Khoa khoa = new Khoa();
            khoa.setTenKhoa(tenKhoa);
            khoa.setMoTa(moTa);
            
            if (khoaDAO.themKhoa(khoa)) {
                JOptionPane.showMessageDialog(view, "Thêm khoa thành công!", 
                        "Thành công", JOptionPane.INFORMATION_MESSAGE);
                loadData();
                view.lamMoiForm();
            } else {
                JOptionPane.showMessageDialog(view, "Không thể thêm khoa!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi thêm khoa: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void suaKhoa() {
        String maKhoaText = view.getTxtMaKhoa().getText().trim();
        String tenKhoa = view.getTxtTenKhoa().getText().trim();
        String moTa = view.getTxtMoTa() != null ? view.getTxtMoTa().getText().trim() : "";

        if (maKhoaText.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Vui lòng chọn khoa cần sửa!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (tenKhoa.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Vui lòng nhập tên khoa!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            view.getTxtTenKhoa().requestFocus();
            return;
        }

        try {
            int maKhoa = Integer.parseInt(maKhoaText);
            Khoa khoa = new Khoa(maKhoa, tenKhoa, moTa);
            
            if (khoaDAO.capNhatKhoa(khoa)) {
                JOptionPane.showMessageDialog(view, "Cập nhật khoa thành công!", 
                        "Thành công", JOptionPane.INFORMATION_MESSAGE);
                loadData();
                view.lamMoiForm();
            } else {
                JOptionPane.showMessageDialog(view, "Không thể cập nhật khoa!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(view, "Mã khoa không hợp lệ!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi cập nhật khoa: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xoaKhoa() {
        String maKhoaText = view.getTxtMaKhoa().getText().trim();

        if (maKhoaText.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Vui lòng chọn khoa cần xóa!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(view, 
                "Bạn có chắc chắn muốn xóa khoa này?\n" +
                "Việc xóa khoa có thể ảnh hưởng đến dữ liệu liên quan.", 
                "Xác nhận xóa", 
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                int maKhoa = Integer.parseInt(maKhoaText);
                
                if (khoaDAO.xoaKhoa(maKhoa)) {
                    JOptionPane.showMessageDialog(view, "Xóa khoa thành công!", 
                            "Thành công", JOptionPane.INFORMATION_MESSAGE);
                    loadData();
                    view.lamMoiForm();
                } else {
                    JOptionPane.showMessageDialog(view, 
                            "Không thể xóa khoa!\nCó thể khoa này đang được sử dụng bởi dữ liệu khác.", 
                            "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(view, "Mã khoa không hợp lệ!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(view, "Lỗi khi xóa khoa: " + ex.getMessage(),
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void hienThiKhoaDuocChon(int row) {
        try {
            DefaultTableModel model = view.getModelKhoa();
            if (row >= 0 && row < model.getRowCount()) {
                view.getTxtMaKhoa().setText(model.getValueAt(row, 0).toString());
                view.getTxtTenKhoa().setText(model.getValueAt(row, 1).toString());
                if (view.getTxtMoTa() != null && model.getValueAt(row, 2) != null) {
                    view.getTxtMoTa().setText(model.getValueAt(row, 2).toString());
                }
            }
        } catch (Exception ex) {
            System.err.println("Lỗi khi hiển thị khoa được chọn: " + ex.getMessage());
        }
    }
    
    public void timKiemKhoa(String tenKhoa) {
        try {
            DefaultTableModel model = view.getModelKhoa();
            model.setRowCount(0);
            
            List<Khoa> danhSachKhoa;
            if (tenKhoa == null || tenKhoa.trim().isEmpty()) {
                danhSachKhoa = khoaDAO.layTatCaKhoa();
            } else {
                danhSachKhoa = khoaDAO.timKhoaTheoTen(tenKhoa);
            }
            
            for (Khoa khoa : danhSachKhoa) {
                model.addRow(new Object[]{
                    khoa.getMaKhoa(),
                    khoa.getTenKhoa(),
                    khoa.getMoTa()
                });
            }
            
            if (tenKhoa != null && !tenKhoa.trim().isEmpty()) {
                if (danhSachKhoa.isEmpty()) {
                    JOptionPane.showMessageDialog(view, 
                            "Không tìm thấy khoa nào với từ khóa: " + tenKhoa, 
                            "Kết quả tìm kiếm", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    System.out.println("Tìm thấy " + danhSachKhoa.size() + " khoa");
                }
            }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi tìm kiếm: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void dongKetNoi() {
        if (khoaDAO != null) {
            khoaDAO.closeConnection();
        }
    }
}