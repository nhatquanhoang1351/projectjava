package controller;

import view.QuanLyDangKyHocPhanPanel;
import model.DangKyHocPhan;
import model.SinhVien;
import model.LopHocPhan;
import dao.DangKyHocPhanDAO;
import dao.SinhVienDAO;
import dao.LopHocPhanDAO;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.util.List;

public class QuanLyDangKyHocPhanController {
    private QuanLyDangKyHocPhanPanel view;
    private DangKyHocPhanDAO dangKyHocPhanDAO;
    private SinhVienDAO sinhVienDAO;
    private LopHocPhanDAO lopHocPhanDAO;

    public QuanLyDangKyHocPhanController(QuanLyDangKyHocPhanPanel view) {
        this.view = view;
        this.dangKyHocPhanDAO = new DangKyHocPhanDAO();
        this.sinhVienDAO = new SinhVienDAO();
        this.lopHocPhanDAO = new LopHocPhanDAO();
        
        initController();
        loadData();
        loadComboBoxes();
    }

    private void initController() {
        view.themSuKienThem(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                themDangKy();
            }
        });

        view.themSuKienSua(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                suaDangKy();
            }
        });

        view.themSuKienXoa(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xoaDangKy();
            }
        });

        view.themSuKienLamMoi(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadData();
                view.lamMoiForm();
            }
        });

        view.themSuKienChonDong(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = view.getTblDangKy().getSelectedRow();
                    if (selectedRow != -1) {
                        hienThiDangKyDuocChon(selectedRow);
                    }
                }
            }
        });

        view.themSuKienTimKiem(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timKiemDangKy();
            }
        });
    }

    private void loadData() {
        try {
            List<DangKyHocPhan> danhSachDangKy = dangKyHocPhanDAO.layTatCaDangKy();
            DefaultTableModel model = view.getModelDangKy();
            model.setRowCount(0);
            
            for (DangKyHocPhan dk : danhSachDangKy) {
                LopHocPhan lopHocPhan = lopHocPhanDAO.timLopHocPhanTheoMa(dk.getMaLopHocPhan());
                
                model.addRow(new Object[]{
                    dk.getMaDangKy(),
                    dk.getHoTenSinhVien(),
                    lopHocPhan != null ? lopHocPhan.getTenLopHocPhan() : "",
                    dk.getNgayDangKy(),
                    dk.getTrangThai()
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi tải dữ liệu: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadComboBoxes() {
        List<SinhVien> danhSachSinhVien = sinhVienDAO.layTatCaSinhVien();
        JComboBox<String> cboSinhVien = view.getCboSinhVien();
        cboSinhVien.removeAllItems();
        cboSinhVien.addItem("-- Chọn sinh viên --");
        for (SinhVien sv : danhSachSinhVien) {
            cboSinhVien.addItem(sv.getHoTen());
        }

        List<LopHocPhan> danhSachLopHocPhan = lopHocPhanDAO.layTatCaLopHocPhan();
        JComboBox<String> cboLopHocPhan = view.getCboLopHocPhan();
        cboLopHocPhan.removeAllItems();
        cboLopHocPhan.addItem("-- Chọn lớp học phần --");
        for (LopHocPhan lhp : danhSachLopHocPhan) {
            cboLopHocPhan.addItem(lhp.getTenLopHocPhan());
        }
    }

    private void themDangKy() {
        try {
            String tenSinhVien = (String) view.getCboSinhVien().getSelectedItem();
            String tenLopHocPhan = (String) view.getCboLopHocPhan().getSelectedItem();
            String trangThai = (String) view.getCboTrangThai().getSelectedItem();

            if (tenSinhVien.equals("-- Chọn sinh viên --") || 
                tenLopHocPhan.equals("-- Chọn lớp học phần --")) {
                JOptionPane.showMessageDialog(view, "Vui lòng chọn đầy đủ thông tin!");
                return;
            }

            List<SinhVien> danhSachSinhVien = sinhVienDAO.timSinhVienTheoTen(tenSinhVien);
            List<LopHocPhan> danhSachLopHocPhan = lopHocPhanDAO.timLopHocPhanTheoTen(tenLopHocPhan);

            if (danhSachSinhVien.isEmpty() || danhSachLopHocPhan.isEmpty()) {
                JOptionPane.showMessageDialog(view, "Không tìm thấy sinh viên hoặc lớp học phần!");
                return;
            }

            SinhVien sinhVien = danhSachSinhVien.get(0);
            LopHocPhan lopHocPhan = danhSachLopHocPhan.get(0);

            DangKyHocPhan dangKy = new DangKyHocPhan();
            dangKy.setMaSinhVien(sinhVien.getMaSinhVien());
            dangKy.setMaLopHocPhan(lopHocPhan.getMaLopHocPhan());
            dangKy.setHoTenSinhVien(sinhVien.getHoTen());
            dangKy.setNgayDangKy(LocalDateTime.now());
            dangKy.setTrangThai(trangThai);

            if (dangKyHocPhanDAO.themDangKy(dangKy)) {
                JOptionPane.showMessageDialog(view, "Thêm đăng ký thành công!");
                loadData();
                view.lamMoiForm();
            } else {
                JOptionPane.showMessageDialog(view, "Thêm đăng ký thất bại!");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi thêm đăng ký: " + ex.getMessage());
        }
    }

    private void suaDangKy() {
        try {
            int maDangKy = Integer.parseInt(view.getTxtMaDangKy().getText().trim());
            String tenSinhVien = (String) view.getCboSinhVien().getSelectedItem();
            String tenLopHocPhan = (String) view.getCboLopHocPhan().getSelectedItem();
            String trangThai = (String) view.getCboTrangThai().getSelectedItem();

            List<SinhVien> danhSachSinhVien = sinhVienDAO.timSinhVienTheoTen(tenSinhVien);
            List<LopHocPhan> danhSachLopHocPhan = lopHocPhanDAO.timLopHocPhanTheoTen(tenLopHocPhan);

            if (danhSachSinhVien.isEmpty() || danhSachLopHocPhan.isEmpty()) {
                JOptionPane.showMessageDialog(view, "Không tìm thấy sinh viên hoặc lớp học phần!");
                return;
            }

            SinhVien sinhVien = danhSachSinhVien.get(0);
            LopHocPhan lopHocPhan = danhSachLopHocPhan.get(0);

            DangKyHocPhan dangKy = dangKyHocPhanDAO.timDangKyTheoMa(maDangKy);
            if (dangKy == null) {
                JOptionPane.showMessageDialog(view, "Không tìm thấy đăng ký!");
                return;
            }

            dangKy.setMaSinhVien(sinhVien.getMaSinhVien());
            dangKy.setMaLopHocPhan(lopHocPhan.getMaLopHocPhan());
            dangKy.setHoTenSinhVien(sinhVien.getHoTen());
            dangKy.setTrangThai(trangThai);

            if (dangKyHocPhanDAO.capNhatDangKy(dangKy)) {
                JOptionPane.showMessageDialog(view, "Cập nhật đăng ký thành công!");
                loadData();
                view.lamMoiForm();
            } else {
                JOptionPane.showMessageDialog(view, "Cập nhật đăng ký thất bại!");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi cập nhật đăng ký: " + ex.getMessage());
        }
    }

    private void xoaDangKy() {
        try {
            int maDangKy = Integer.parseInt(view.getTxtMaDangKy().getText().trim());
            
            int confirm = JOptionPane.showConfirmDialog(view, 
                "Bạn có chắc chắn muốn xóa đăng ký này?", 
                "Xác nhận xóa", 
                JOptionPane.YES_NO_OPTION);
                
            if (confirm == JOptionPane.YES_OPTION) {
                if (dangKyHocPhanDAO.xoaDangKy(maDangKy)) {
                    JOptionPane.showMessageDialog(view, "Xóa đăng ký thành công!");
                    loadData();
                    view.lamMoiForm();
                } else {
                    JOptionPane.showMessageDialog(view, "Xóa đăng ký thất bại!");
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi xóa đăng ký: " + ex.getMessage());
        }
    }

    private void timKiemDangKy() {
        String tuKhoa = view.getTxtSearch().getText().trim();
        if (tuKhoa.isEmpty()) {
            loadData();
            return;
        }

        try {
            List<DangKyHocPhan> ketQua = dangKyHocPhanDAO.timDangKyTheoTrangThai(tuKhoa);
            DefaultTableModel model = view.getModelDangKy();
            model.setRowCount(0);

            for (DangKyHocPhan dk : ketQua) {
                LopHocPhan lopHocPhan = lopHocPhanDAO.timLopHocPhanTheoMa(dk.getMaLopHocPhan());
                
                model.addRow(new Object[]{
                    dk.getMaDangKy(),
                    dk.getHoTenSinhVien(),
                    lopHocPhan != null ? lopHocPhan.getTenLopHocPhan() : "",
                    dk.getNgayDangKy(),
                    dk.getTrangThai()
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi tìm kiếm: " + ex.getMessage());
        }
    }

    private void hienThiDangKyDuocChon(int row) {
        DefaultTableModel model = view.getModelDangKy();
        int maDangKy = Integer.parseInt(model.getValueAt(row, 0).toString());
        
        DangKyHocPhan dangKy = dangKyHocPhanDAO.timDangKyTheoMa(maDangKy);
        if (dangKy != null) {
            view.getTxtMaDangKy().setText(String.valueOf(dangKy.getMaDangKy()));
            view.getCboSinhVien().setSelectedItem(dangKy.getHoTenSinhVien());
            
            LopHocPhan lopHocPhan = lopHocPhanDAO.timLopHocPhanTheoMa(dangKy.getMaLopHocPhan());
            if (lopHocPhan != null) {
                view.getCboLopHocPhan().setSelectedItem(lopHocPhan.getTenLopHocPhan());
            }
            
            view.getCboTrangThai().setSelectedItem(dangKy.getTrangThai());
        }
    }
}