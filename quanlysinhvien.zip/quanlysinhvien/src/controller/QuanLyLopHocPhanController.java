package controller;

import view.QuanLyLopHocPhanPanel;
import view.BangDiemDialog;
import model.LopHocPhan;
import model.MonHoc;
import model.GiangVien;
import model.SinhVien;
import model.Diem;
import model.DangKyHocPhan;
import dao.LopHocPhanDAO;
import dao.MonHocDAO;
import dao.GiangVienDAO;
import dao.SinhVienDAO;
import dao.DiemDAO;
import dao.DangKyHocPhanDAO;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QuanLyLopHocPhanController {
    private QuanLyLopHocPhanPanel view;
    private LopHocPhanDAO lopHocPhanDAO;
    private MonHocDAO monHocDAO;
    private GiangVienDAO giangVienDAO;
    private SinhVienDAO sinhVienDAO;
    private DiemDAO diemDAO;
    private DangKyHocPhanDAO dangKyHocPhanDAO;
    private BangDiemDialog bangDiemDialog;

    public QuanLyLopHocPhanController(QuanLyLopHocPhanPanel view) {
        this.view = view;
        this.lopHocPhanDAO = new LopHocPhanDAO();
        this.monHocDAO = new MonHocDAO();
        this.giangVienDAO = new GiangVienDAO();
        this.sinhVienDAO = new SinhVienDAO();
        this.diemDAO = new DiemDAO();
        this.dangKyHocPhanDAO = new DangKyHocPhanDAO();
        
        view.themSuKienThem(new ThemLopHocPhanListener());
        view.themSuKienSua(new SuaLopHocPhanListener());
        view.themSuKienXoa(new XoaLopHocPhanListener());
        view.themSuKienLamMoi(new LamMoiListener());
        view.themSuKienChonDong(new ChonDongListener());
        view.themSuKienTimKiem(new TimKiemListener());
        view.themSuKienXemDiem(new XemDiemListener());
        
        loadData();
        loadComboBoxes();
    }

    private void loadData() {
        List<LopHocPhan> danhSachLopHocPhan = lopHocPhanDAO.layTatCaLopHocPhan();
        DefaultTableModel model = view.getModelLopHocPhan();
        model.setRowCount(0);
        
        for (LopHocPhan lhp : danhSachLopHocPhan) {
            MonHoc monHoc = monHocDAO.timMonHocTheoMa(lhp.getMaMonHoc());
            GiangVien giangVien = giangVienDAO.timGiangVienTheoMa(lhp.getMaGiangVien());
            
            model.addRow(new Object[]{
                lhp.getMaLopHocPhan(),
                lhp.getTenLopHocPhan(),
                monHoc != null ? monHoc.getTenMonHoc() : "",
                giangVien != null ? giangVien.getHoTen() : "",
                lhp.getSiSo(),
                lhp.getHocKy(),
                lhp.getNamHoc()
            });
        }
    }

    private void loadComboBoxes() {
        List<MonHoc> danhSachMonHoc = monHocDAO.layTatCaMonHoc();
        JComboBox<String> cboMonHoc = view.getCboMonHoc();
        cboMonHoc.removeAllItems();
        cboMonHoc.addItem("-- Chọn môn học --");
        for (MonHoc mh : danhSachMonHoc) {
            cboMonHoc.addItem(mh.getTenMonHoc());
        }

        List<GiangVien> danhSachGiangVien = giangVienDAO.layTatCaGiangVien();
        JComboBox<String> cboGiangVien = view.getCboGiangVien();
        cboGiangVien.removeAllItems();
        cboGiangVien.addItem("-- Chọn giảng viên --");
        for (GiangVien gv : danhSachGiangVien) {
            cboGiangVien.addItem(gv.getHoTen());
        }
    }

    private class ThemLopHocPhanListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                String tenLopHocPhan = view.getTxtTenLopHocPhan().getText().trim();
                String tenMonHoc = (String) view.getCboMonHoc().getSelectedItem();
                String tenGiangVien = (String) view.getCboGiangVien().getSelectedItem();
                int siSo = Integer.parseInt(view.getTxtSiSoToiDa().getText().trim());
                String hocKy = (String) view.getCboHocKy().getSelectedItem();
                int namHoc = Integer.parseInt(view.getTxtNamHoc().getText().trim());

                if (tenLopHocPhan.isEmpty() || tenMonHoc.equals("-- Chọn môn học --") || 
                    tenGiangVien.equals("-- Chọn giảng viên --")) {
                    JOptionPane.showMessageDialog(view, "Vui lòng nhập đầy đủ thông tin!");
                    return;
                }

                List<MonHoc> danhSachMonHoc = monHocDAO.timMonHocTheoTen(tenMonHoc);
                List<GiangVien> danhSachGiangVien = giangVienDAO.timGiangVienTheoTen(tenGiangVien);

                if (danhSachMonHoc.isEmpty() || danhSachGiangVien.isEmpty()) {
                    JOptionPane.showMessageDialog(view, "Không tìm thấy môn học hoặc giảng viên!");
                    return;
                }

                MonHoc monHoc = danhSachMonHoc.get(0);
                GiangVien giangVien = danhSachGiangVien.get(0);

                LopHocPhan lopHocPhan = new LopHocPhan();
                lopHocPhan.setTenLopHocPhan(tenLopHocPhan);
                lopHocPhan.setMaMonHoc(monHoc.getMaMonHoc());
                lopHocPhan.setMaGiangVien(giangVien.getMaGiangVien());
                lopHocPhan.setSiSo(siSo);
                lopHocPhan.setHocKy(hocKy);
                lopHocPhan.setNamHoc(namHoc);

                if (lopHocPhanDAO.themLopHocPhan(lopHocPhan)) {
                    JOptionPane.showMessageDialog(view, "Thêm lớp học phần thành công!");
                    loadData();
                    view.lamMoiForm();
                } else {
                    JOptionPane.showMessageDialog(view, "Thêm lớp học phần thất bại!");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(view, "Sĩ số tối đa và năm học phải là số!");
            }
        }
    }

    private class SuaLopHocPhanListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int maLopHocPhan = Integer.parseInt(view.getTxtMaLopHocPhan().getText().trim());
                String tenLopHocPhan = view.getTxtTenLopHocPhan().getText().trim();
                String tenMonHoc = (String) view.getCboMonHoc().getSelectedItem();
                String tenGiangVien = (String) view.getCboGiangVien().getSelectedItem();
                int siSo = Integer.parseInt(view.getTxtSiSoToiDa().getText().trim());
                String hocKy = (String) view.getCboHocKy().getSelectedItem();
                int namHoc = Integer.parseInt(view.getTxtNamHoc().getText().trim());

                if (tenLopHocPhan.isEmpty() || tenMonHoc.equals("-- Chọn môn học --") || 
                    tenGiangVien.equals("-- Chọn giảng viên --")) {
                    JOptionPane.showMessageDialog(view, "Vui lòng nhập đầy đủ thông tin!");
                    return;
                }

                List<MonHoc> danhSachMonHoc = monHocDAO.timMonHocTheoTen(tenMonHoc);
                List<GiangVien> danhSachGiangVien = giangVienDAO.timGiangVienTheoTen(tenGiangVien);

                if (danhSachMonHoc.isEmpty() || danhSachGiangVien.isEmpty()) {
                    JOptionPane.showMessageDialog(view, "Không tìm thấy môn học hoặc giảng viên!");
                    return;
                }

                MonHoc monHoc = danhSachMonHoc.get(0);
                GiangVien giangVien = danhSachGiangVien.get(0);

                LopHocPhan lopHocPhan = new LopHocPhan();
                lopHocPhan.setMaLopHocPhan(maLopHocPhan);
                lopHocPhan.setTenLopHocPhan(tenLopHocPhan);
                lopHocPhan.setMaMonHoc(monHoc.getMaMonHoc());
                lopHocPhan.setMaGiangVien(giangVien.getMaGiangVien());
                lopHocPhan.setSiSo(siSo);
                lopHocPhan.setHocKy(hocKy);
                lopHocPhan.setNamHoc(namHoc);

                if (lopHocPhanDAO.capNhatLopHocPhan(lopHocPhan)) {
                    JOptionPane.showMessageDialog(view, "Cập nhật lớp học phần thành công!");
                    loadData();
                    view.lamMoiForm();
                } else {
                    JOptionPane.showMessageDialog(view, "Cập nhật lớp học phần thất bại!");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(view, "Mã LHP, sĩ số tối đa và năm học phải là số!");
            }
        }
    }

    private class XoaLopHocPhanListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int maLopHocPhan = Integer.parseInt(view.getTxtMaLopHocPhan().getText().trim());
                
                int confirm = JOptionPane.showConfirmDialog(view, 
                    "Bạn có chắc chắn muốn xóa lớp học phần này?", 
                    "Xác nhận xóa", 
                    JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    if (lopHocPhanDAO.xoaLopHocPhan(maLopHocPhan)) {
                        JOptionPane.showMessageDialog(view, "Xóa lớp học phần thành công!");
                        loadData();
                        view.lamMoiForm();
                    } else {
                        JOptionPane.showMessageDialog(view, "Xóa lớp học phần thất bại!");
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(view, "Mã LHP không hợp lệ!");
            }
        }
    }

    private class LamMoiListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            view.lamMoiForm();
        }
    }

    private class ChonDongListener implements ListSelectionListener {
        @Override
        public void valueChanged(ListSelectionEvent e) {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = view.getTblLopHocPhan().getSelectedRow();
                if (selectedRow != -1) {
                    DefaultTableModel model = view.getModelLopHocPhan();
                    view.getTxtMaLopHocPhan().setText(model.getValueAt(selectedRow, 0).toString());
                    view.getTxtTenLopHocPhan().setText(model.getValueAt(selectedRow, 1).toString());
                    view.getCboMonHoc().setSelectedItem(model.getValueAt(selectedRow, 2).toString());
                    view.getCboGiangVien().setSelectedItem(model.getValueAt(selectedRow, 3).toString());
                    view.getTxtSiSoToiDa().setText(model.getValueAt(selectedRow, 4).toString());
                    view.getCboHocKy().setSelectedItem(model.getValueAt(selectedRow, 5).toString());
                    view.getTxtNamHoc().setText(model.getValueAt(selectedRow, 6).toString());
                }
            }
        }
    }

    private class XemDiemListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = view.getTblLopHocPhan().getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(view, "Vui lòng chọn một lớp học phần!");
                return;
            }

            int maLopHocPhan = Integer.parseInt(view.getModelLopHocPhan().getValueAt(selectedRow, 0).toString());
            String tenLopHocPhan = view.getModelLopHocPhan().getValueAt(selectedRow, 1).toString();

            if (bangDiemDialog == null) {
                bangDiemDialog = new BangDiemDialog(SwingUtilities.getWindowAncestor(view), "Bảng điểm - " + tenLopHocPhan);
            } else {
                bangDiemDialog.setTitle("Bảng điểm - " + tenLopHocPhan);
            }

            loadDanhSachDiemSinhVien(maLopHocPhan);
            bangDiemDialog.setVisible(true);
        }
    }

    private void loadDanhSachDiemSinhVien(int maLopHocPhan) {
        DefaultTableModel model = bangDiemDialog.getModelDiemSinhVien();
        model.setRowCount(0);

        List<DangKyHocPhan> danhSachDangKy = dangKyHocPhanDAO.timDangKyTheoLopHocPhan(maLopHocPhan);
        
        List<Diem> danhSachDiem = diemDAO.timDiemTheoLopHocPhan(maLopHocPhan);
        
        Map<Integer, Diem> mapDiem = new HashMap<>();
        for (Diem diem : danhSachDiem) {
            mapDiem.put(diem.getMaSinhVien(), diem);
        }

        for (DangKyHocPhan dkhp : danhSachDangKy) {
            if (dkhp.getTrangThai().equals("DANG_KY")) {
                SinhVien sinhVien = sinhVienDAO.timSinhVienTheoMa(dkhp.getMaSinhVien());
                if (sinhVien != null) {
                    Diem diem = mapDiem.get(sinhVien.getMaSinhVien());
                    if (diem != null) {
                        double diemTrungBinh = (diem.getDiemChuyenCan() * 0.1 + 
                                              diem.getDiemGiuaKy() * 0.3 + 
                                              diem.getDiemCuoiKy() * 0.6);
                        
                        model.addRow(new Object[]{
                            sinhVien.getMaSinhVien(),
                            sinhVien.getHoTen(),
                            diem.getDiemChuyenCan(),
                            diem.getDiemGiuaKy(),
                            diem.getDiemCuoiKy(),
                            String.format("%.2f", diemTrungBinh)
                        });
                    }
                }
            }
        }
    }

    private class TimKiemListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String tuKhoa = view.getTxtSearch().getText().trim();
            if (tuKhoa.isEmpty()) {
                loadData();
                return;
            }

            List<LopHocPhan> ketQua = lopHocPhanDAO.timLopHocPhanTheoTen(tuKhoa);
            DefaultTableModel model = view.getModelLopHocPhan();
            model.setRowCount(0);

            for (LopHocPhan lhp : ketQua) {
                MonHoc monHoc = monHocDAO.timMonHocTheoMa(lhp.getMaMonHoc());
                GiangVien giangVien = giangVienDAO.timGiangVienTheoMa(lhp.getMaGiangVien());
                
                model.addRow(new Object[]{
                    lhp.getMaLopHocPhan(),
                    lhp.getTenLopHocPhan(),
                    monHoc != null ? monHoc.getTenMonHoc() : "",
                    giangVien != null ? giangVien.getHoTen() : "",
                    lhp.getSiSo(),
                    lhp.getHocKy(),
                    lhp.getNamHoc()
                });
            }
        }
    }
}