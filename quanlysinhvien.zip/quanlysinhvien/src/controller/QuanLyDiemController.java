package controller;

import view.QuanLyDiemPanel;
import dao.DiemDAO;
import dao.SinhVienDAO;
import dao.LopHocPhanDAO;
import model.Diem;
import model.SinhVien;
import model.LopHocPhan;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class QuanLyDiemController {
    private QuanLyDiemPanel view;
    private DiemDAO diemDAO;
    private SinhVienDAO sinhVienDAO;
    private LopHocPhanDAO lopHocPhanDAO;

    public QuanLyDiemController(QuanLyDiemPanel view) {
        this.view = view;
        this.diemDAO = new DiemDAO();
        this.sinhVienDAO = new SinhVienDAO();
        this.lopHocPhanDAO = new LopHocPhanDAO();
        initController();
        loadData();
        loadComboBoxSinhVien();
        loadComboBoxNamHoc();
        loadComboBoxHocKy();
    }

    private void initController() {
        view.themSuKienThem(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                themDiem();
            }
        });

        view.themSuKienSua(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                suaDiem();
            }
        });

        view.themSuKienXoa(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xoaDiem();
            }
        });

        view.themSuKienLamMoi(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadData();
                view.lamMoiForm();
            }
        });

        view.themSuKienChonDong(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = view.getTblDiem().getSelectedRow();
                    if (selectedRow != -1) {
                        hienThiDiemDuocChon(selectedRow);
                    }
                }
            }
        });

        view.getCboSinhVien().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadComboBoxLopHocPhan();
            }
        });

        view.getCboHocKy().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadComboBoxLopHocPhan();
            }
        });

        view.themSuKienTimKiem(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timKiemDiem();
            }
        });
    }

    private void loadData() {
        try {
            DefaultTableModel model = view.getModelDiem();
            model.setRowCount(0);
            List<Diem> danhSachDiem = diemDAO.layTatCaDiem();
            
            for (Diem diem : danhSachDiem) {
                SinhVien sv = sinhVienDAO.timSinhVienTheoMa(diem.getMaSinhVien());
                LopHocPhan lhp = lopHocPhanDAO.timLopHocPhanTheoMa(diem.getMaLopHocPhan());
                
                model.addRow(new Object[]{
                    diem.getMaDiem(),
                    sv.getMaSo(),
                    sv.getHoTen(),
                    lhp.getMaLopHocPhan(),
                    lhp.getTenLopHocPhan(),
                    diem.getDiemChuyenCan(),
                    diem.getDiemGiuaKy(),
                    diem.getDiemCuoiKy(),
                    diem.getDiemTrungBinh()
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi tải dữ liệu: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadComboBoxSinhVien() {
        try {
            JComboBox<String> cboSinhVien = view.getCboSinhVien();
            cboSinhVien.removeAllItems();
            
            List<SinhVien> danhSachSinhVien = sinhVienDAO.layTatCaSinhVien();
            for (SinhVien sv : danhSachSinhVien) {
                cboSinhVien.addItem(sv.getMaSinhVien() + " - " + sv.getHoTen());
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi tải danh sách sinh viên: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadComboBoxNamHoc() {
        JComboBox<String> cboNamHoc = view.getCboNamHoc();
        cboNamHoc.removeAllItems();
        cboNamHoc.addItem("2024");
        cboNamHoc.addItem("2023");
        cboNamHoc.addItem("2022");
    }

    private void loadComboBoxHocKy() {
        JComboBox<String> cboHocKy = view.getCboHocKy();
        cboHocKy.removeAllItems();
        cboHocKy.addItem("2024-1");
        cboHocKy.addItem("2024-2");
    }

    private void loadComboBoxLopHocPhan() {
        try {
            JComboBox<String> cboLopHocPhan = view.getCboLopHocPhan();
            cboLopHocPhan.removeAllItems();
            cboLopHocPhan.setEnabled(false);

            String selectedSinhVien = (String) view.getCboSinhVien().getSelectedItem();
            String selectedNamHoc = (String) view.getCboNamHoc().getSelectedItem();
            String selectedHocKy = (String) view.getCboHocKy().getSelectedItem();

            if (selectedSinhVien != null && selectedNamHoc != null && selectedHocKy != null) {
                int maSinhVien = Integer.parseInt(selectedSinhVien.split(" - ")[0]);
                List<LopHocPhan> danhSachLHP = lopHocPhanDAO.layLopHocPhanTheoSinhVien(maSinhVien, selectedNamHoc, selectedHocKy);
                
                if (!danhSachLHP.isEmpty()) {
                    cboLopHocPhan.setEnabled(true);
                    for (LopHocPhan lhp : danhSachLHP) {
                        cboLopHocPhan.addItem(lhp.getMaLopHocPhan() + " - " + lhp.getTenLopHocPhan());
                    }
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi tải danh sách lớp học phần: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void themDiem() {
        try {
            String selectedSinhVien = (String) view.getCboSinhVien().getSelectedItem();
            String selectedLopHocPhan = (String) view.getCboLopHocPhan().getSelectedItem();
            String diemChuyenCanStr = view.getTxtDiemChuyenCan().getText().trim();
            String diemGiuaKyStr = view.getTxtDiemGiuaKy().getText().trim();
            String diemCuoiKyStr = view.getTxtDiemCuoiKy().getText().trim();

            if (selectedSinhVien == null || selectedLopHocPhan == null) {
                JOptionPane.showMessageDialog(view, "Vui lòng chọn sinh viên và lớp học phần!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (diemChuyenCanStr.isEmpty() || diemGiuaKyStr.isEmpty() || diemCuoiKyStr.isEmpty()) {
                JOptionPane.showMessageDialog(view, "Vui lòng nhập đầy đủ điểm!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            float diemChuyenCan = Float.parseFloat(diemChuyenCanStr);
            float diemGiuaKy = Float.parseFloat(diemGiuaKyStr);
            float diemCuoiKy = Float.parseFloat(diemCuoiKyStr);
            int maSinhVien = Integer.parseInt(selectedSinhVien.split(" - ")[0]);
            int maLopHocPhan = Integer.parseInt(selectedLopHocPhan.split(" - ")[0]);

            if (diemChuyenCan < 0 || diemChuyenCan > 10 || 
                diemGiuaKy < 0 || diemGiuaKy > 10 || 
                diemCuoiKy < 0 || diemCuoiKy > 10) {
                JOptionPane.showMessageDialog(view, "Điểm phải từ 0 đến 10!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            float diemTrungBinh = (diemChuyenCan + diemGiuaKy + diemCuoiKy) / 3;

            Diem diem = new Diem();
            diem.setMaSinhVien(maSinhVien);
            diem.setMaLopHocPhan(maLopHocPhan);
            diem.setDiemChuyenCan(diemChuyenCan);
            diem.setDiemGiuaKy(diemGiuaKy);
            diem.setDiemCuoiKy(diemCuoiKy);
            diem.setDiemTrungBinh(diemTrungBinh);

            if (diemDAO.themDiem(diem)) {
                JOptionPane.showMessageDialog(view, "Thêm điểm thành công!");
                loadData();
                view.lamMoiForm();
            } else {
                JOptionPane.showMessageDialog(view, "Thêm điểm thất bại!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(view, "Điểm phải là số!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi thêm điểm: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void suaDiem() {
        try {
            String maDiemStr = view.getTxtMaDiem().getText().trim();
            String selectedSinhVien = (String) view.getCboSinhVien().getSelectedItem();
            String selectedLopHocPhan = (String) view.getCboLopHocPhan().getSelectedItem();
            String diemChuyenCanStr = view.getTxtDiemChuyenCan().getText().trim();
            String diemGiuaKyStr = view.getTxtDiemGiuaKy().getText().trim();
            String diemCuoiKyStr = view.getTxtDiemCuoiKy().getText().trim();

            if (maDiemStr.isEmpty()) {
                JOptionPane.showMessageDialog(view, "Vui lòng chọn điểm cần sửa!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (selectedSinhVien == null || selectedLopHocPhan == null) {
                JOptionPane.showMessageDialog(view, "Vui lòng chọn sinh viên và lớp học phần!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (diemChuyenCanStr.isEmpty() || diemGiuaKyStr.isEmpty() || diemCuoiKyStr.isEmpty()) {
                JOptionPane.showMessageDialog(view, "Vui lòng nhập đầy đủ điểm!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            float diemChuyenCan = Float.parseFloat(diemChuyenCanStr);
            float diemGiuaKy = Float.parseFloat(diemGiuaKyStr);
            float diemCuoiKy = Float.parseFloat(diemCuoiKyStr);
            int maDiem = Integer.parseInt(maDiemStr);
            int maSinhVien = Integer.parseInt(selectedSinhVien.split(" - ")[0]);
            int maLopHocPhan = Integer.parseInt(selectedLopHocPhan.split(" - ")[0]);

            if (diemChuyenCan < 0 || diemChuyenCan > 10 || 
                diemGiuaKy < 0 || diemGiuaKy > 10 || 
                diemCuoiKy < 0 || diemCuoiKy > 10) {
                JOptionPane.showMessageDialog(view, "Điểm phải từ 0 đến 10!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            float diemTrungBinh = (diemChuyenCan + diemGiuaKy + diemCuoiKy) / 3;

            Diem diem = new Diem();
            diem.setMaDiem(maDiem);
            diem.setMaSinhVien(maSinhVien);
            diem.setMaLopHocPhan(maLopHocPhan);
            diem.setDiemChuyenCan(diemChuyenCan);
            diem.setDiemGiuaKy(diemGiuaKy);
            diem.setDiemCuoiKy(diemCuoiKy);
            diem.setDiemTrungBinh(diemTrungBinh);

            if (diemDAO.capNhatDiem(diem)) {
                JOptionPane.showMessageDialog(view, "Cập nhật điểm thành công!");
                loadData();
                view.lamMoiForm();
            } else {
                JOptionPane.showMessageDialog(view, "Cập nhật điểm thất bại!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(view, "Điểm phải là số!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi cập nhật điểm: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xoaDiem() {
        String maDiemStr = view.getTxtMaDiem().getText().trim();

        if (maDiemStr.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Vui lòng chọn điểm cần xóa!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(view, 
                "Bạn có chắc chắn muốn xóa điểm này?", 
                "Xác nhận xóa", 
                JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                int maDiem = Integer.parseInt(maDiemStr);
                if (diemDAO.xoaDiem(maDiem)) {
                    JOptionPane.showMessageDialog(view, "Xóa điểm thành công!");
                    loadData();
                    view.lamMoiForm();
                } else {
                    JOptionPane.showMessageDialog(view, "Xóa điểm thất bại!");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(view, "Mã điểm không hợp lệ!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(view, "Lỗi khi xóa điểm: " + ex.getMessage(),
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void hienThiDiemDuocChon(int row) {
        DefaultTableModel model = view.getModelDiem();
        view.getTxtMaDiem().setText(model.getValueAt(row, 0).toString());
        
        String maSinhVien = model.getValueAt(row, 1).toString();
        String hoTen = model.getValueAt(row, 2).toString();
        String sinhVienItem = maSinhVien + " - " + hoTen;
        view.getCboSinhVien().setSelectedItem(sinhVienItem);
        
        String maLopHocPhan = model.getValueAt(row, 3).toString();
        String tenMonHoc = model.getValueAt(row, 4).toString();
        String lopHocPhanItem = maLopHocPhan + " - " + tenMonHoc;
        view.getCboLopHocPhan().setSelectedItem(lopHocPhanItem);
        
        view.getTxtDiemChuyenCan().setText(model.getValueAt(row, 5).toString());
        view.getTxtDiemGiuaKy().setText(model.getValueAt(row, 6).toString());
        view.getTxtDiemCuoiKy().setText(model.getValueAt(row, 7).toString());
    }

    private void timKiemDiem() {
        String tuKhoa = view.getTxtSearch().getText().trim();
        if (tuKhoa.isEmpty()) {
            loadData();
            return;
        }

        try {
            DefaultTableModel model = view.getModelDiem();
            model.setRowCount(0);
            
            List<Diem> ketQua = diemDAO.timDiem(tuKhoa);
            
            for (Diem diem : ketQua) {
                SinhVien sv = sinhVienDAO.timSinhVienTheoMa(diem.getMaSinhVien());
                LopHocPhan lhp = lopHocPhanDAO.timLopHocPhanTheoMa(diem.getMaLopHocPhan());
                
                model.addRow(new Object[]{
                    diem.getMaDiem(),
                    sv.getMaSo(),
                    sv.getHoTen(),
                    lhp.getMaLopHocPhan(),
                    lhp.getTenLopHocPhan(),
                    diem.getDiemChuyenCan(),
                    diem.getDiemGiuaKy(),
                    diem.getDiemCuoiKy(),
                    diem.getDiemTrungBinh()
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Lỗi khi tìm kiếm: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
} 