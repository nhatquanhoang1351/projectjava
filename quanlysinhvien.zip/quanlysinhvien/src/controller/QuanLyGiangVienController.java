package controller;

import view.QuanLyGiangVienPanel;
import model.GiangVien;
import model.Khoa;
import dao.GiangVienDAO;
import dao.KhoaDAO;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class QuanLyGiangVienController {
    private QuanLyGiangVienPanel view;
    private GiangVienDAO giangVienDAO;
    private KhoaDAO khoaDAO;

    public QuanLyGiangVienController(QuanLyGiangVienPanel view) {
        this.view = view;
        this.giangVienDAO = new GiangVienDAO();
        this.khoaDAO = new KhoaDAO();
        
        view.themSuKienThem(new ThemGiangVienListener());
        view.themSuKienSua(new SuaGiangVienListener());
        view.themSuKienXoa(new XoaGiangVienListener());
        view.themSuKienLamMoi(new LamMoiListener());
        view.themSuKienChonDong(new ChonDongListener());
        view.getBtnSearch().addActionListener(new TimKiemListener());
        
        loadData();
        loadComboBoxes();
    }

    private void loadData() {
        List<GiangVien> danhSachGiangVien = giangVienDAO.layTatCaGiangVien();
        DefaultTableModel model = view.getModelGiangVien();
        model.setRowCount(0);
        
        for (GiangVien gv : danhSachGiangVien) {
            model.addRow(new Object[]{
                gv.getMaGiangVien(),
                gv.getHoTen(),
                gv.getEmail(),
                gv.getSoDienThoai(),
                gv.getHocVi(),
                gv.getHocHam(),
                gv.getMaKhoa()
            });
        }
    }

    private void loadComboBoxes() {
        List<Khoa> danhSachKhoa = khoaDAO.layTatCaKhoa();
        JComboBox<String> cboKhoa = view.getCboKhoa();
        cboKhoa.removeAllItems();
        cboKhoa.addItem("-- Chọn khoa --");
        for (Khoa k : danhSachKhoa) {
            cboKhoa.addItem(k.getTenKhoa());
        }
    }

    private class ThemGiangVienListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                String hoTen = view.getTxtHoTen().getText().trim();
                String email = view.getTxtEmail().getText().trim();
                String soDienThoai = view.getTxtSoDienThoai().getText().trim();
                String hocVi = (String) view.getCboHocVi().getSelectedItem();
                String hocHam = (String) view.getCboHocHam().getSelectedItem();
                String tenKhoa = (String) view.getCboKhoa().getSelectedItem();

                if (hoTen.isEmpty() || email.isEmpty() || soDienThoai.isEmpty() || 
                    hocVi.equals("-- Chọn học vị --") || hocHam.equals("-- Chọn học hàm --") || 
                    tenKhoa.equals("-- Chọn khoa --")) {
                    JOptionPane.showMessageDialog(view, "Vui lòng nhập đầy đủ thông tin!");
                    return;
                }

                List<Khoa> danhSachKhoa = khoaDAO.timKhoaTheoTen(tenKhoa);
                if (danhSachKhoa.isEmpty()) {
                    JOptionPane.showMessageDialog(view, "Không tìm thấy khoa!");
                    return;
                }

                Khoa khoa = danhSachKhoa.get(0);

                GiangVien giangVien = new GiangVien();
                giangVien.setHoTen(hoTen);
                giangVien.setEmail(email);
                giangVien.setSoDienThoai(soDienThoai);
                giangVien.setHocVi(hocVi);
                giangVien.setHocHam(hocHam);
                giangVien.setMaKhoa(khoa.getMaKhoa());

                if (giangVienDAO.themGiangVien(giangVien)) {
                    JOptionPane.showMessageDialog(view, "Thêm giảng viên thành công!");
                    loadData();
                    view.lamMoiForm();
                } else {
                    JOptionPane.showMessageDialog(view, "Thêm giảng viên thất bại!");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(view, "Có lỗi xảy ra: " + ex.getMessage());
            }
        }
    }

    private class SuaGiangVienListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int maGiangVien = Integer.parseInt(view.getTxtMaGiangVien().getText().trim());
                String hoTen = view.getTxtHoTen().getText().trim();
                String email = view.getTxtEmail().getText().trim();
                String soDienThoai = view.getTxtSoDienThoai().getText().trim();
                String hocVi = (String) view.getCboHocVi().getSelectedItem();
                String hocHam = (String) view.getCboHocHam().getSelectedItem();
                String tenKhoa = (String) view.getCboKhoa().getSelectedItem();

                if (hoTen.isEmpty() || email.isEmpty() || soDienThoai.isEmpty() || 
                    hocVi.equals("-- Chọn học vị --") || hocHam.equals("-- Chọn học hàm --") || 
                    tenKhoa.equals("-- Chọn khoa --")) {
                    JOptionPane.showMessageDialog(view, "Vui lòng nhập đầy đủ thông tin!");
                    return;
                }

                List<Khoa> danhSachKhoa = khoaDAO.timKhoaTheoTen(tenKhoa);
                if (danhSachKhoa.isEmpty()) {
                    JOptionPane.showMessageDialog(view, "Không tìm thấy khoa!");
                    return;
                }

                Khoa khoa = danhSachKhoa.get(0);

                GiangVien giangVien = new GiangVien();
                giangVien.setMaGiangVien(maGiangVien);
                giangVien.setHoTen(hoTen);
                giangVien.setEmail(email);
                giangVien.setSoDienThoai(soDienThoai);
                giangVien.setHocVi(hocVi);
                giangVien.setHocHam(hocHam);
                giangVien.setMaKhoa(khoa.getMaKhoa());

                if (giangVienDAO.capNhatGiangVien(giangVien)) {
                    JOptionPane.showMessageDialog(view, "Cập nhật giảng viên thành công!");
                    loadData();
                    view.lamMoiForm();
                } else {
                    JOptionPane.showMessageDialog(view, "Cập nhật giảng viên thất bại!");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(view, "Mã giảng viên không hợp lệ!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(view, "Có lỗi xảy ra: " + ex.getMessage());
            }
        }
    }

    private class XoaGiangVienListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int maGiangVien = Integer.parseInt(view.getTxtMaGiangVien().getText().trim());
                
                int confirm = JOptionPane.showConfirmDialog(view, 
                    "Bạn có chắc chắn muốn xóa giảng viên này?", 
                    "Xác nhận xóa", 
                    JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    if (giangVienDAO.xoaGiangVien(maGiangVien)) {
                        JOptionPane.showMessageDialog(view, "Xóa giảng viên thành công!");
                        loadData();
                        view.lamMoiForm();
                    } else {
                        JOptionPane.showMessageDialog(view, "Xóa giảng viên thất bại!");
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(view, "Mã giảng viên không hợp lệ!");
            }
        }
    }

    private class LamMoiListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            view.lamMoiForm();
        }
    }

    private class ChonDongListener implements ListSelectionListener {
        @Override
        public void valueChanged(ListSelectionEvent e) {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = view.getTblGiangVien().getSelectedRow();
                if (selectedRow != -1) {
                    DefaultTableModel model = view.getModelGiangVien();
                    view.getTxtMaGiangVien().setText(model.getValueAt(selectedRow, 0).toString());
                    view.getTxtHoTen().setText(model.getValueAt(selectedRow, 1).toString());
                    view.getTxtEmail().setText(model.getValueAt(selectedRow, 2).toString());
                    view.getTxtSoDienThoai().setText(model.getValueAt(selectedRow, 3).toString());
                    view.getCboHocVi().setSelectedItem(model.getValueAt(selectedRow, 4).toString());
                    view.getCboHocHam().setSelectedItem(model.getValueAt(selectedRow, 5).toString());
                    
                    int maKhoa = Integer.parseInt(model.getValueAt(selectedRow, 6).toString());
                    Khoa khoa = khoaDAO.timKhoaTheoMa(maKhoa);
                    if (khoa != null) {
                        view.getCboKhoa().setSelectedItem(khoa.getTenKhoa());
                    }
                }
            }
        }
    }

    private class TimKiemListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String tuKhoa = view.getTxtSearch().getText().trim();
            if (tuKhoa.isEmpty()) {
                loadData();
                return;
            }

            List<GiangVien> ketQua = giangVienDAO.timGiangVienTheoTen(tuKhoa);
            DefaultTableModel model = view.getModelGiangVien();
            model.setRowCount(0);

            for (GiangVien gv : ketQua) {
                model.addRow(new Object[]{
                    gv.getMaGiangVien(),
                    gv.getHoTen(),
                    gv.getEmail(),
                    gv.getSoDienThoai(),
                    gv.getHocVi(),
                    gv.getHocHam(),
                    gv.getMaKhoa()
                });
            }
        }
    }
} 