package view;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class ManHinhChinh extends JFrame {
    private JPanel sidebar;
    private JPanel contentPanel;
    private JPanel welcomePanel;
    private Color primaryColor = new Color(33, 150, 243);
    private Color sidebarColor = new Color(33, 33, 33);
    private Color textColor = new Color(33, 33, 33);
    private JButton btnKhoa, btnLop, btnSinhVien, btnMonHoc, btnDiem, btnGiangVien, btnDangKyLop;
    private JLabel lblUserInfo;
    private JButton btnLogout;
    
    private QuanLyKhoaPanel quanLyKhoaPanel;
    private QuanLyLopHocPhanPanel quanLyLopHocPhanPanel;
    private QuanLyGiangVienPanel quanLyGiangVienPanel;
    private QuanLySinhVienPanel quanLySinhVienPanel;
    private QuanLyMonHocPanel quanLyMonHocPanel;
    private QuanLyDiemPanel quanLyDiemPanel;
    private QuanLyDangKyHocPhanPanel quanLyDangKyHocPhanPanel;
    public ManHinhChinh() {
        setTitle("Hệ thống quản lý sinh viên");
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
        initPanels(); 
        addEventListeners(); 
        showWelcomePanel();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setBackground(sidebarColor);
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        JPanel logoPanel = new JPanel();
        logoPanel.setBackground(sidebarColor);
        logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.Y_AXIS));
        logoPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 30, 20));

        JLabel lblTitle = new JLabel("QUẢN LÝ SINH VIÊN");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoPanel.add(lblTitle);

        sidebar.add(logoPanel);

        btnKhoa = createMenuButton("Quản lý Khoa");
        btnLop = createMenuButton("Lớp mỗi kỳ");
        btnDangKyLop = createMenuButton("Đăng ký lớp cho sinh viên");
        btnSinhVien = createMenuButton("Quản lý Sinh viên");
        btnMonHoc = createMenuButton("Quản lý Môn học");
        btnDiem = createMenuButton("Quản lý Điểm");
        btnGiangVien = createMenuButton("Quản lý Giảng Viên");

        sidebar.add(btnKhoa);
        sidebar.add(btnLop);
        sidebar.add(btnDangKyLop);
        sidebar.add(btnSinhVien);
        sidebar.add(btnMonHoc);
        sidebar.add(btnDiem);
        sidebar.add(btnGiangVien);

        sidebar.add(Box.createVerticalGlue());

        JPanel userPanel = new JPanel();
        userPanel.setBackground(sidebarColor);
        userPanel.setLayout(new BoxLayout(userPanel, BoxLayout.Y_AXIS));
        userPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        lblUserInfo = new JLabel("Admin");
        lblUserInfo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblUserInfo.setForeground(Color.WHITE);
        lblUserInfo.setAlignmentX(Component.CENTER_ALIGNMENT);
        userPanel.add(lblUserInfo);

        btnLogout = new JButton("Đăng xuất");
        btnLogout.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setBackground(new Color(244, 67, 54));
        btnLogout.setFocusPainted(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogout.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLogout.setMaximumSize(new Dimension(150, 35));
        btnLogout.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Bạn có chắc chắn muốn đăng xuất?",
                "Xác nhận đăng xuất",
                JOptionPane.YES_NO_OPTION);
                
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new LoginFrame().setVisible(true);
            }
        });

        userPanel.add(Box.createVerticalStrut(10));
        userPanel.add(btnLogout);
        sidebar.add(userPanel);

        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(Color.WHITE);

        add(sidebar, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
    }
    
    private void initPanels() {
        quanLyKhoaPanel = new QuanLyKhoaPanel();
        quanLyLopHocPhanPanel = new QuanLyLopHocPhanPanel();
        quanLySinhVienPanel = new QuanLySinhVienPanel();
        quanLyMonHocPanel = new QuanLyMonHocPanel();
        quanLyDiemPanel = new QuanLyDiemPanel();
        quanLyGiangVienPanel = new QuanLyGiangVienPanel();
        quanLyDangKyHocPhanPanel = new QuanLyDangKyHocPhanPanel();
    }
    
    private JPanel createTemporaryPanel(String title, String description) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
        
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(Color.WHITE);
        
        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(primaryColor);
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel lblDescription = new JLabel(description);
        lblDescription.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblDescription.setForeground(textColor);
        lblDescription.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        content.add(lblTitle);
        content.add(Box.createVerticalStrut(20));
        content.add(lblDescription);
        
        panel.add(content, BorderLayout.CENTER);
        return panel;
    }
    
    private void addEventListeners() {
        btnKhoa.addActionListener(e -> showPanel(quanLyKhoaPanel));
        btnGiangVien.addActionListener(e -> showPanel(quanLyGiangVienPanel));
        btnLop.addActionListener(e -> showPanel(quanLyLopHocPhanPanel));
        btnSinhVien.addActionListener(e -> showPanel(quanLySinhVienPanel));
        btnMonHoc.addActionListener(e -> showPanel(quanLyMonHocPanel));
        btnDiem.addActionListener(e -> showPanel(quanLyDiemPanel));
        btnDangKyLop.addActionListener(e -> showPanel(quanLyDangKyHocPhanPanel));
    }
    
    private void showPanel(JPanel panel) {
        contentPanel.removeAll();
        contentPanel.add(panel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private JButton createMenuButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(sidebarColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(230, 40));
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        button.setHorizontalAlignment(SwingConstants.LEFT);

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(primaryColor);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(sidebarColor);
            }
        });

        return button;
    }

    private void showWelcomePanel() {
        welcomePanel = new JPanel(new BorderLayout());
        welcomePanel.setBackground(Color.WHITE);
        welcomePanel.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));

        JPanel welcomeContent = new JPanel();
        welcomeContent.setLayout(new BoxLayout(welcomeContent, BoxLayout.Y_AXIS));
        welcomeContent.setBackground(Color.WHITE);

        JLabel lblWelcome = new JLabel("Chào mừng đến với");
        lblWelcome.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        lblWelcome.setForeground(textColor);
        lblWelcome.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblSystemName = new JLabel("HỆ THỐNG QUẢN LÝ SINH VIÊN");
        lblSystemName.setFont(new Font("Segoe UI", Font.BOLD, 32));
        lblSystemName.setForeground(primaryColor);
        lblSystemName.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblDescription = new JLabel("Vui lòng chọn chức năng từ menu bên trái");
        lblDescription.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblDescription.setForeground(textColor);
        lblDescription.setAlignmentX(Component.CENTER_ALIGNMENT);

        welcomeContent.add(lblWelcome);
        welcomeContent.add(Box.createVerticalStrut(10));
        welcomeContent.add(lblSystemName);
        welcomeContent.add(Box.createVerticalStrut(20));
        welcomeContent.add(lblDescription);

        welcomePanel.add(welcomeContent, BorderLayout.CENTER);
        showPanel(welcomePanel);
    }

    // Getter methods
    public JButton getBtnKhoa() {
        return btnKhoa;
    }

    public JButton getBtnLop() {
        return btnLop;
    }

    public JButton getBtnSinhVien() {
        return btnSinhVien;
    }

    public JButton getBtnMonHoc() {
        return btnMonHoc;
    }

    public JButton getBtnDiem() {
        return btnDiem;
    }
    public JButton getBtnDangKyLop() {
        return btnDangKyLop;
    }    
    public JButton getBtnGiangVien() {
        return btnGiangVien;
    }

    public JPanel getContentPanel() {
        return contentPanel;
    }
    
    public QuanLyKhoaPanel getQuanLyKhoaPanel() {
        return quanLyKhoaPanel;
    }
}