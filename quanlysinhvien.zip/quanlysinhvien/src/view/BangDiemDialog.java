package view;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class BangDiemDialog extends JDialog {
    private JTable tblDiemSinhVien;
    private DefaultTableModel modelDiemSinhVien;
    private Color primaryColor = new Color(33, 150, 243);
    private Color backgroundColor = new Color(245, 245, 245);
    private Color textColor = new Color(33, 33, 33);

    public BangDiemDialog(Window parent, String title) {
        super(parent, title, ModalityType.APPLICATION_MODAL);
        setLayout(new BorderLayout());
        setBackground(backgroundColor);
        initComponents();
        pack();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {

        String[] cot = {"Mã SV", "Họ tên", "Điểm chuyên cần", "Điểm giữa kỳ", "Điểm cuối kỳ", "Điểm trung bình"};
        modelDiemSinhVien = new DefaultTableModel(cot, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblDiemSinhVien = new JTable(modelDiemSinhVien);
        JTableHeader header = tblDiemSinhVien.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(primaryColor);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(header.getWidth(), 40));
        
        tblDiemSinhVien.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tblDiemSinhVien.setRowHeight(30);
        tblDiemSinhVien.setSelectionBackground(new Color(33, 150, 243, 50));
        tblDiemSinhVien.setSelectionForeground(textColor);
        tblDiemSinhVien.setGridColor(new Color(200, 200, 200));
        tblDiemSinhVien.setShowGrid(true);
        tblDiemSinhVien.setIntercellSpacing(new Dimension(0, 0));
        
        JScrollPane scrollPane = new JScrollPane(tblDiemSinhVien);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setBackground(backgroundColor);
        
        JLabel lblTitle = new JLabel("DANH SÁCH ĐIỂM SINH VIÊN");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTitle.setForeground(primaryColor);
        lblTitle.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        
        JButton btnClose = new JButton("Đóng");
        btnClose.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnClose.setBackground(primaryColor);
        btnClose.setForeground(Color.WHITE);
        btnClose.setFocusPainted(false);
        btnClose.setBorderPainted(false);
        btnClose.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnClose.setPreferredSize(new Dimension(100, 35));
        btnClose.addActionListener(e -> dispose());
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(backgroundColor);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));
        buttonPanel.add(btnClose);
        
        add(lblTitle, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        setMinimumSize(new Dimension(800, 500));
        setResizable(true);
    }

    public DefaultTableModel getModelDiemSinhVien() {
        return modelDiemSinhVien;
    }
} 