package view;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import javax.swing.event.ListSelectionListener;

public class QuanLyDiemPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    
    private static final Color PRIMARY_COLOR = new Color(0, 123, 255);
    private static final Color BACKGROUND_COLOR = new Color(240, 240, 240);
    private static final Color TEXT_COLOR = new Color(33, 37, 41);
    
    private JTable tblDiem;
    private DefaultTableModel modelDiem;
    private JTextField txtMaDiem;
    private JComboBox<String> cboSinhVien;
    private JComboBox<String> cboNamHoc;
    private JComboBox<String> cboHocKy;
    private JComboBox<String> cboLopHocPhan;
    private JTextField txtDiemChuyenCan;
    private JTextField txtDiemGiuaKy;
    private JTextField txtDiemCuoiKy;
    private JTextField txtSearch;
    
    public QuanLyDiemPanel() {
        setLayout(new BorderLayout());
        setBackground(BACKGROUND_COLOR);
        
        taoBangDiem();
        
        JPanel searchPanel = taoPanelTimKiem();
        
        JPanel formPanel = taoPanelForm();
        
        JPanel buttonPanel = taoPanelNut();
        
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(BACKGROUND_COLOR);
        topPanel.add(searchPanel, BorderLayout.NORTH);
        topPanel.add(formPanel, BorderLayout.CENTER);
        
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(BACKGROUND_COLOR);
        bottomPanel.add(buttonPanel, BorderLayout.CENTER);
        
        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(tblDiem), BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }
    
    private void taoBangDiem() {
        String[] columns = {"STT", "Mã sinh viên", "Họ tên", "Mã lớp", "Tên môn học", 
                          "Điểm chuyên cần", "Điểm giữa kỳ", "Điểm cuối kỳ", "Điểm trung bình"};
        modelDiem = new DefaultTableModel(columns, 0) {
            private static final long serialVersionUID = 1L;
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex >= 5 && columnIndex <= 8) {
                    return Float.class;
                }
                return String.class;
            }
        };
        
        tblDiem = new JTable(modelDiem);
        tblDiem.setRowHeight(30);
        tblDiem.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblDiem.setShowGrid(false);
        tblDiem.setIntercellSpacing(new Dimension(0, 0));
        
        JTableHeader header = tblDiem.getTableHeader();
        header.setPreferredSize(new Dimension(header.getWidth(), 40));
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.BLACK);
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        tblDiem.getColumnModel().getColumn(0).setPreferredWidth(80);  
        tblDiem.getColumnModel().getColumn(1).setPreferredWidth(100); 
        tblDiem.getColumnModel().getColumn(2).setPreferredWidth(200);
        tblDiem.getColumnModel().getColumn(3).setPreferredWidth(100); 
        tblDiem.getColumnModel().getColumn(4).setPreferredWidth(200); 
        tblDiem.getColumnModel().getColumn(5).setPreferredWidth(120); 
        tblDiem.getColumnModel().getColumn(6).setPreferredWidth(100); 
        tblDiem.getColumnModel().getColumn(7).setPreferredWidth(100); 
        tblDiem.getColumnModel().getColumn(8).setPreferredWidth(120); 
    }
    
    private JPanel taoPanelTimKiem() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel lblSearch = new JLabel("Tìm kiếm:");
        lblSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        txtSearch = new JTextField(20);
        txtSearch.setPreferredSize(new Dimension(200, 30));
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        JButton btnSearch = new JButton("Tìm kiếm");
        btnSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnSearch.setBackground(PRIMARY_COLOR);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFocusPainted(false);
        btnSearch.setBorderPainted(false);
        
        panel.add(lblSearch);
        panel.add(txtSearch);
        panel.add(btnSearch);
        
        return panel;
    }
    
    private JPanel taoPanelForm() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(taoLabel("STT"), gbc);
        
        gbc.gridx = 1;
        txtMaDiem = taoTextField();
        txtMaDiem.setEditable(false);
        panel.add(txtMaDiem, gbc);
        
        gbc.gridx = 2;
        panel.add(taoLabel("Sinh viên:"), gbc);
        
        gbc.gridx = 3;
        cboSinhVien = taoComboBox();
        panel.add(cboSinhVien, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(taoLabel("Năm học:"), gbc);
        
        gbc.gridx = 1;
        cboNamHoc = taoComboBox();
        panel.add(cboNamHoc, gbc);
        
        gbc.gridx = 2;
        panel.add(taoLabel("Học kỳ:"), gbc);
        
        gbc.gridx = 3;
        cboHocKy = taoComboBox();
        panel.add(cboHocKy, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(taoLabel("Lớp học phần:"), gbc);

        gbc.gridx = 1; gbc.gridwidth = 3;
        cboLopHocPhan = taoComboBox(); // Sửa lỗi: sử dụng cboLopHocPhan thay vì txtLopHocPhan
        panel.add(cboLopHocPhan, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 1;
        panel.add(taoLabel("Điểm chuyên cần:"), gbc);
        
        gbc.gridx = 1;
        txtDiemChuyenCan = taoTextField();
        panel.add(txtDiemChuyenCan, gbc);
        
        gbc.gridx = 2;
        panel.add(taoLabel("Điểm giữa kỳ:"), gbc);
        
        gbc.gridx = 3;
        txtDiemGiuaKy = taoTextField();
        panel.add(txtDiemGiuaKy, gbc);
        
        gbc.gridx = 0; gbc.gridy = 4;
        panel.add(taoLabel("Điểm cuối kỳ:"), gbc);
        
        gbc.gridx = 1;
        txtDiemCuoiKy = taoTextField();
        panel.add(txtDiemCuoiKy, gbc);
        
        return panel;
    }
    
    private JPanel taoPanelNut() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JButton btnThem = taoNut("Thêm", PRIMARY_COLOR);
        JButton btnSua = taoNut("Sửa", new Color(40, 167, 69));
        JButton btnXoa = taoNut("Xóa", new Color(220, 53, 69));
        JButton btnLamMoi = taoNut("Làm mới", new Color(108, 117, 125));
        
        panel.add(btnThem);
        panel.add(btnSua);
        panel.add(btnXoa);
        panel.add(btnLamMoi);
        
        return panel;
    }
    
    private JLabel taoLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        return label;
    }
    
    private JTextField taoTextField() {
        JTextField textField = new JTextField(15);
        textField.setPreferredSize(new Dimension(200, 30));
        textField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        return textField;
    }
    
    private JComboBox<String> taoComboBox() {
        JComboBox<String> comboBox = new JComboBox<>();
        comboBox.setPreferredSize(new Dimension(200, 30));
        comboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        return comboBox;
    }
    
    private JButton taoNut(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(100, 35));
        return button;
    }
    
    // Getters
    public JTable getTblDiem() {
        return tblDiem;
    }
    
    public DefaultTableModel getModelDiem() {
        return modelDiem;
    }
    
    public JTextField getTxtMaDiem() {
        return txtMaDiem;
    }
    
    public JComboBox<String> getCboSinhVien() {
        return cboSinhVien;
    }
    
    public JComboBox<String> getCboNamHoc() {
        return cboNamHoc;
    }
    
    public JComboBox<String> getCboHocKy() {
        return cboHocKy;
    }
    
    public JComboBox<String> getCboLopHocPhan() {
        return cboLopHocPhan;
    }
    
    public JTextField getTxtDiemChuyenCan() {
        return txtDiemChuyenCan;
    }
    
    public JTextField getTxtDiemGiuaKy() {
        return txtDiemGiuaKy;
    }
    
    public JTextField getTxtDiemCuoiKy() {
        return txtDiemCuoiKy;
    }
    
    public JTextField getTxtSearch() {
        return txtSearch;
    }
    
    public void lamMoiForm() {
        txtMaDiem.setText("");
        cboSinhVien.setSelectedIndex(-1);
        cboNamHoc.setSelectedIndex(-1);
        cboHocKy.setSelectedIndex(-1);
        cboLopHocPhan.setSelectedIndex(-1);
        txtDiemChuyenCan.setText("");
        txtDiemGiuaKy.setText("");
        txtDiemCuoiKy.setText("");
        txtSearch.setText("");
    }
    
    public void themSuKienThem(ActionListener listener) {
        Component[] components = getComponents();
        for (Component component : components) {
            if (component instanceof JPanel) {
                JPanel panel = (JPanel) component;
                Component[] panelComponents = panel.getComponents();
                for (Component panelComponent : panelComponents) {
                    if (panelComponent instanceof JPanel) {
                        JPanel buttonPanel = (JPanel) panelComponent;
                        Component[] buttons = buttonPanel.getComponents();
                        for (Component button : buttons) {
                            if (button instanceof JButton && ((JButton) button).getText().equals("Thêm")) {
                                ((JButton) button).addActionListener(listener);
                            }
                        }
                    }
                }
            }
        }
    }
    
    public void themSuKienSua(ActionListener listener) {
        Component[] components = getComponents();
        for (Component component : components) {
            if (component instanceof JPanel) {
                JPanel panel = (JPanel) component;
                Component[] panelComponents = panel.getComponents();
                for (Component panelComponent : panelComponents) {
                    if (panelComponent instanceof JPanel) {
                        JPanel buttonPanel = (JPanel) panelComponent;
                        Component[] buttons = buttonPanel.getComponents();
                        for (Component button : buttons) {
                            if (button instanceof JButton && ((JButton) button).getText().equals("Sửa")) {
                                ((JButton) button).addActionListener(listener);
                            }
                        }
                    }
                }
            }
        }
    }
    
    public void themSuKienXoa(ActionListener listener) {
        Component[] components = getComponents();
        for (Component component : components) {
            if (component instanceof JPanel) {
                JPanel panel = (JPanel) component;
                Component[] panelComponents = panel.getComponents();
                for (Component panelComponent : panelComponents) {
                    if (panelComponent instanceof JPanel) {
                        JPanel buttonPanel = (JPanel) panelComponent;
                        Component[] buttons = buttonPanel.getComponents();
                        for (Component button : buttons) {
                            if (button instanceof JButton && ((JButton) button).getText().equals("Xóa")) {
                                ((JButton) button).addActionListener(listener);
                            }
                        }
                    }
                }
            }
        }
    }
    
    public void themSuKienLamMoi(ActionListener listener) {
        Component[] components = getComponents();
        for (Component component : components) {
            if (component instanceof JPanel) {
                JPanel panel = (JPanel) component;
                Component[] panelComponents = panel.getComponents();
                for (Component panelComponent : panelComponents) {
                    if (panelComponent instanceof JPanel) {
                        JPanel buttonPanel = (JPanel) panelComponent;
                        Component[] buttons = buttonPanel.getComponents();
                        for (Component button : buttons) {
                            if (button instanceof JButton && ((JButton) button).getText().equals("Làm mới")) {
                                ((JButton) button).addActionListener(listener);
                            }
                        }
                    }
                }
            }
        }
    }
    
    public void themSuKienChonDong(ListSelectionListener listener) {
        tblDiem.getSelectionModel().addListSelectionListener(listener);
    }
    
    public void themSuKienTimKiem(ActionListener listener) {
        Component[] components = getComponents();
        for (Component component : components) {
            if (component instanceof JPanel) {
                JPanel panel = (JPanel) component;
                Component[] panelComponents = panel.getComponents();
                for (Component panelComponent : panelComponents) {
                    if (panelComponent instanceof JButton && ((JButton) panelComponent).getText().equals("Tìm kiếm")) {
                        ((JButton) panelComponent).addActionListener(listener);
                    }
                }
            }
        }
    }
}