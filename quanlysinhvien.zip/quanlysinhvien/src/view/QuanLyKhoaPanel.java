package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.border.TitledBorder;

public class QuanLyKhoaPanel extends JPanel {
    private JTable tblKhoa;
    private DefaultTableModel modelKhoa;
    private TableRowSorter<DefaultTableModel> sorter;
    private JTextField txtMaKhoa, txtTenKhoa, txtMoTa, txtTimKiem;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi, btnTimKiem;
    private JPanel panelForm, panelButton, panelTimKiem, panelTable;
    
    private static final Color PRIMARY_COLOR = new Color(70, 130, 180);
    private static final Color SUCCESS_COLOR = new Color(40, 167, 69);
    private static final Color DANGER_COLOR = new Color(220, 53, 69);
    private static final Color WARNING_COLOR = new Color(255, 193, 7);
    private static final Color LIGHT_GRAY = new Color(248, 249, 250);
    private static final Color BORDER_COLOR = new Color(206, 212, 218);

    public QuanLyKhoaPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        setBackground(Color.WHITE);
        
        taoTimKiem();
        taoBangKhoa();
        taoFormNhapLieu();
        taoPanelNut();
        
        SwingUtilities.invokeLater(() -> txtTimKiem.requestFocus());
    }

    private void taoTimKiem() {
        panelTimKiem = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        panelTimKiem.setBackground(LIGHT_GRAY);
        panelTimKiem.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            "Tìm kiếm",
            TitledBorder.LEFT,
            TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 12),
            PRIMARY_COLOR
        ));

        JLabel lblTimKiem = new JLabel("Tên khoa:");
        lblTimKiem.setFont(new Font("Arial", Font.PLAIN, 12));
        
        txtTimKiem = new JTextField(20);
        txtTimKiem.setFont(new Font("Arial", Font.PLAIN, 12));
        txtTimKiem.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        
        btnTimKiem = new JButton("Tìm kiếm");
        styleButton(btnTimKiem);
        
        panelTimKiem.add(lblTimKiem);
        panelTimKiem.add(txtTimKiem);
        panelTimKiem.add(btnTimKiem);
        
        add(panelTimKiem, BorderLayout.NORTH);
    }

    private void taoBangKhoa() {
        panelTable = new JPanel(new BorderLayout());
        panelTable.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            "Danh sách khoa",
            TitledBorder.LEFT,
            TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 12),
            PRIMARY_COLOR
        ));

        String[] cot = {"Mã Khoa", "Tên Khoa", "Mô tả"};
        modelKhoa = new DefaultTableModel(cot, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblKhoa = new JTable(modelKhoa);
        tblKhoa.setFont(new Font("Arial", Font.PLAIN, 12));
        tblKhoa.setRowHeight(25);
        tblKhoa.setGridColor(BORDER_COLOR);
        tblKhoa.setSelectionBackground(PRIMARY_COLOR.brighter());
        tblKhoa.setSelectionForeground(Color.WHITE);
        tblKhoa.setShowGrid(true);
        
        JTableHeader header = tblKhoa.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 12));
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.BLACK);
        header.setBorder(BorderFactory.createLineBorder(PRIMARY_COLOR.darker()));
        
        sorter = new TableRowSorter<>(modelKhoa);
        tblKhoa.setRowSorter(sorter);
        
        tblKhoa.getColumnModel().getColumn(0).setPreferredWidth(80);
        tblKhoa.getColumnModel().getColumn(1).setPreferredWidth(200);
        tblKhoa.getColumnModel().getColumn(2).setPreferredWidth(300);
        
        JScrollPane scrollPane = new JScrollPane(tblKhoa);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        scrollPane.getViewport().setBackground(Color.WHITE);
        
        panelTable.add(scrollPane, BorderLayout.CENTER);
        add(panelTable, BorderLayout.CENTER);
    }

    private void taoFormNhapLieu() {
        panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(LIGHT_GRAY);
        panelForm.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            "Thông tin khoa",
            TitledBorder.LEFT,
            TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 12),
            PRIMARY_COLOR
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 10, 8, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        Font labelFont = new Font("Arial", Font.PLAIN, 12);
        Font fieldFont = new Font("Arial", Font.PLAIN, 12);

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        JLabel lblMaKhoa = new JLabel("Mã Khoa:");
        lblMaKhoa.setFont(labelFont);
        panelForm.add(lblMaKhoa, gbc);
        
        gbc.gridx = 1; gbc.weightx = 1;
        txtMaKhoa = new JTextField(20);
        txtMaKhoa.setEditable(false);
        txtMaKhoa.setFont(fieldFont);
        txtMaKhoa.setBackground(new Color(233, 236, 239));
        styleTextField(txtMaKhoa);
        panelForm.add(txtMaKhoa, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        JLabel lblTenKhoa = new JLabel("Tên Khoa:");
        lblTenKhoa.setFont(labelFont);
        panelForm.add(lblTenKhoa, gbc);
        
        gbc.gridx = 1; gbc.weightx = 1;
        txtTenKhoa = new JTextField(20);
        txtTenKhoa.setFont(fieldFont);
        styleTextField(txtTenKhoa);
        panelForm.add(txtTenKhoa, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        JLabel lblMoTa = new JLabel("Mô tả:");
        lblMoTa.setFont(labelFont);
        panelForm.add(lblMoTa, gbc);
        
        gbc.gridx = 1; gbc.weightx = 1;
        txtMoTa = new JTextField(20);
        txtMoTa.setFont(fieldFont);
        styleTextField(txtMoTa);
        panelForm.add(txtMoTa, gbc);

        JPanel formWrapper = new JPanel(new BorderLayout());
        formWrapper.add(panelForm, BorderLayout.WEST);
        add(formWrapper, BorderLayout.EAST);
    }

    private void taoPanelNut() {
        panelButton = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelButton.setBackground(Color.WHITE);
        panelButton.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        btnThem = new JButton("Thêm");
        btnSua = new JButton("Sửa");
        btnXoa = new JButton("Xóa");
        btnLamMoi = new JButton("Làm mới");

        styleButton(btnThem);
        styleButton(btnSua);
        styleButton(btnXoa);
        styleButton(btnLamMoi);

        panelButton.add(btnThem);
        panelButton.add(btnSua);
        panelButton.add(btnXoa);
        panelButton.add(btnLamMoi);

        add(panelButton, BorderLayout.SOUTH);
    }

    private void styleButton(JButton button) {
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setForeground(Color.BLACK);
        button.setBackground(Color.WHITE);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(8, 16, 8, 16)
        ));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(LIGHT_GRAY);
            }
            
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(Color.WHITE);
            }
        });
    }

    private void styleTextField(JTextField textField) {
        textField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        
        textField.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                textField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(PRIMARY_COLOR, 2),
                    BorderFactory.createEmptyBorder(4, 7, 4, 7)
                ));
            }
            
            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                textField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER_COLOR, 1),
                    BorderFactory.createEmptyBorder(5, 8, 5, 8)
                ));
            }
        });
    }

    public JTable getTblKhoa() {
        return tblKhoa;
    }

    public DefaultTableModel getModelKhoa() {
        return modelKhoa;
    }

    public JTextField getTxtMaKhoa() {
        return txtMaKhoa;
    }

    public JTextField getTxtTenKhoa() {
        return txtTenKhoa;
    }

    public JTextField getTxtMoTa() {
        return txtMoTa;
    }

    public JTextField getTxtTimKiem() {
        return txtTimKiem;
    }

    public void themSuKienThem(ActionListener listener) {
        btnThem.addActionListener(listener);
    }

    public void themSuKienSua(ActionListener listener) {
        btnSua.addActionListener(listener);
    }

    public void themSuKienXoa(ActionListener listener) {
        btnXoa.addActionListener(listener);
    }

    public void themSuKienLamMoi(ActionListener listener) {
        btnLamMoi.addActionListener(listener);
    }

    public void themSuKienTimKiem(ActionListener listener) {
        btnTimKiem.addActionListener(listener);
        
        txtTimKiem.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    btnTimKiem.doClick();
                }
            }
        });
    }

    public void themSuKienChonDong(ListSelectionListener listener) {
        tblKhoa.getSelectionModel().addListSelectionListener(listener);
    }

    public void lamMoiForm() {
        txtMaKhoa.setText("");
        txtTenKhoa.setText("");
        txtMoTa.setText("");
        tblKhoa.clearSelection();
        txtTimKiem.setText("");
    }

    public void locBangTheoTen(String tenKhoa) {
        if (tenKhoa == null || tenKhoa.trim().isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + tenKhoa, 1)); 
        }
    }
}