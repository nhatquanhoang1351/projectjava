package view;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.io.*;
import java.util.Properties;

public class LoginFrame extends JFrame {
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JLabel lblStatus;
    private JCheckBox chkRemember;
    private JPanel mainPanel;
    private Color primaryColor = new Color(33, 150, 243);
    private Color backgroundColor = new Color(245, 245, 245);
    private Color textColor = new Color(33, 33, 33);
    private static final String CONFIG_FILE = "login.properties";

    public LoginFrame() {
        setTitle("Đăng nhập hệ thống quản lý sinh viên");
        setSize(450, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setUndecorated(true);
        initComponents();
        createShadowBorder();
        loadSavedCredentials();
    }

    private void loadSavedCredentials() {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(CONFIG_FILE)) {
            props.load(fis);
            String savedUsername = props.getProperty("username");
            String savedPassword = props.getProperty("password");
            boolean remember = Boolean.parseBoolean(props.getProperty("remember", "false"));
            
            if (remember && savedUsername != null && savedPassword != null) {
                txtUsername.setText(savedUsername);
                txtPassword.setText(savedPassword);
                chkRemember.setSelected(true);
            }
        } catch (IOException e) {
        }
    }

    private void saveCredentials(String username, String password, boolean remember) {
        Properties props = new Properties();
        if (remember) {
            props.setProperty("username", username);
            props.setProperty("password", password);
            props.setProperty("remember", "true");
        } else {
            props.setProperty("remember", "false");
        }
        
        try (FileOutputStream fos = new FileOutputStream(CONFIG_FILE)) {
            props.store(fos, "Login Information");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void createShadowBorder() {
        mainPanel.setBorder(BorderFactory.createCompoundBorder(
            new ShadowBorder(20),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
    }

    private void initComponents() {
        mainPanel = new JPanel();
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 16, 12, 16);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("ĐĂNG NHẬP", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(primaryColor);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.insets = new Insets(40, 10, 30, 10);
        mainPanel.add(lblTitle, gbc);
        gbc.insets = new Insets(12, 16, 12, 16);
        gbc.gridwidth = 1;

        JLabel lblUser = new JLabel("Tên đăng nhập");
        lblUser.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblUser.setForeground(textColor);
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        mainPanel.add(lblUser, gbc);

        txtUsername = new JTextField();
        txtUsername.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        txtUsername.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200,200,200), 1, true),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)));
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        mainPanel.add(txtUsername, gbc);

        JLabel lblPass = new JLabel("Mật khẩu");
        lblPass.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblPass.setForeground(textColor);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        mainPanel.add(lblPass, gbc);

        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        txtPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200,200,200), 1, true),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)));
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        mainPanel.add(txtPassword, gbc);

        chkRemember = new JCheckBox("Ghi nhớ đăng nhập");
        chkRemember.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        chkRemember.setForeground(textColor);
        chkRemember.setBackground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(chkRemember, gbc);

        btnLogin = new JButton("ĐĂNG NHẬP") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                super.paintComponent(g);
                g2.dispose();
            }
        };
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnLogin.setBackground(primaryColor);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setBorderPainted(false);
        btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 16, 8, 16);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(btnLogin, gbc);

        lblStatus = new JLabel("", SwingConstants.CENTER);
        lblStatus.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblStatus.setForeground(new Color(244, 67, 54));
        gbc.gridx = 0; gbc.gridy = 7; gbc.gridwidth = 2;
        gbc.insets = new Insets(8, 16, 8, 16);
        mainPanel.add(lblStatus, gbc);

        JButton btnClose = new JButton("×");
        btnClose.setFont(new Font("Segoe UI", Font.BOLD, 20));
        btnClose.setForeground(textColor);
        btnClose.setBackground(Color.WHITE);
        btnClose.setBorderPainted(false);
        btnClose.setFocusPainted(false);
        btnClose.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnClose.addActionListener(e -> System.exit(0));
        
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topPanel.setBackground(Color.WHITE);
        topPanel.add(btnClose);
        
        setLayout(new BorderLayout());
        add(topPanel, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);

        btnLogin.addActionListener(e -> login());
        getRootPane().setDefaultButton(btnLogin);

        btnLogin.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnLogin.setBackground(primaryColor.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnLogin.setBackground(primaryColor);
            }
        });
    }

    private void login() {
        String user = txtUsername.getText().trim();
        String pass = new String(txtPassword.getPassword());
        if (user.equals("admin") && pass.equals("admin")) {
            saveCredentials(user, pass, chkRemember.isSelected());
            SwingUtilities.invokeLater(() -> {
                dispose();
                new ManHinhChinh().setVisible(true);
            });
        } else {
            lblStatus.setText("Sai tên đăng nhập hoặc mật khẩu!");
            txtPassword.setText("");
            txtPassword.requestFocus();
        }
    }

    private class ShadowBorder extends AbstractBorder {
        private int shadowSize;
        
        public ShadowBorder(int shadowSize) {
            this.shadowSize = shadowSize;
        }
        
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            int shadowOffset = 5;
            g2d.setColor(new Color(0, 0, 0, 50));
            g2d.fill(new RoundRectangle2D.Float(x + shadowOffset, y + shadowOffset, 
                    width - shadowOffset * 2, height - shadowOffset * 2, 10, 10));
            
            g2d.setColor(Color.WHITE);
            g2d.fill(new RoundRectangle2D.Float(x, y, width - shadowOffset * 2, 
                    height - shadowOffset * 2, 10, 10));
            
            g2d.dispose();
        }
    }
}