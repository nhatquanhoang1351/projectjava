package view;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import javax.swing.event.ListSelectionListener;

public class QuanLyLopHocPhanPanel extends JPanel {
    private JTable tblLopHocPhan;
    private DefaultTableModel modelLopHocPhan;
    private JTextField txtMaLopHocPhan, txtTenLopHocPhan, txtSiSoToiDa, txtNamHoc;
    private JComboBox<String> cboMonHoc, cboGiangVien, cboHocKy;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi, btnXemDiem;
    private JPanel panelForm, panelButton, panelSearch;
    private JTextField txtSearch;
    private Color primaryColor = new Color(33, 150, 243);
    private Color backgroundColor = new Color(245, 245, 245);
    private Color textColor = new Color(33, 33, 33);

    public QuanLyLopHocPhanPanel() {
        setLayout(new BorderLayout());
        setBackground(backgroundColor);
        taoBangLopHocPhan();
        taoPanelTimKiem();
        taoFormNhapLieu();
        taoPanelNut();
    }

    private void taoBangLopHocPhan() {
        String[] cot = {"Mã LHP", "Tên LHP", "Môn học", "Giảng viên", "Sĩ số tối đa", "Học kỳ", "Năm học"};
        modelLopHocPhan = new DefaultTableModel(cot, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblLopHocPhan = new JTable(modelLopHocPhan);
        
        JTableHeader header = tblLopHocPhan.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(primaryColor);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(header.getWidth(), 40));
        
        tblLopHocPhan.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tblLopHocPhan.setRowHeight(30);
        tblLopHocPhan.setSelectionBackground(new Color(33, 150, 243, 50));
        tblLopHocPhan.setSelectionForeground(textColor);
        tblLopHocPhan.setGridColor(new Color(200, 200, 200));
        tblLopHocPhan.setShowGrid(true);
        tblLopHocPhan.setIntercellSpacing(new Dimension(0, 0));
        
        JScrollPane scrollPane = new JScrollPane(tblLopHocPhan);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setBackground(backgroundColor);
        
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(backgroundColor);
        tablePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        add(tablePanel, BorderLayout.CENTER);
    }

    private void taoPanelTimKiem() {
        panelSearch = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelSearch.setBackground(backgroundColor);
        panelSearch.setBorder(BorderFactory.createEmptyBorder(20, 20, 0, 20));

        JLabel lblSearch = new JLabel("Tìm kiếm:");
        lblSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSearch.setForeground(textColor);
        panelSearch.add(lblSearch);

        txtSearch = new JTextField(20);
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setPreferredSize(new Dimension(200, 35));
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panelSearch.add(txtSearch);

        JButton btnSearch = new JButton("Tìm kiếm");
        btnSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnSearch.setBackground(primaryColor);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFocusPainted(false);
        btnSearch.setBorderPainted(false);
        btnSearch.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSearch.setPreferredSize(new Dimension(100, 35));
        panelSearch.add(btnSearch);

        add(panelSearch, BorderLayout.NORTH);
    }

    private void taoFormNhapLieu() {
        panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(backgroundColor);
        panelForm.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel lblTitle = new JLabel("THÔNG TIN LỚP HỌC PHẦN");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(primaryColor);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 20, 0);
        formPanel.add(lblTitle, gbc);
        gbc.insets = new Insets(8, 8, 8, 8);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        formPanel.add(createLabel("Mã LHP:"), gbc);
        gbc.gridx = 1;
        txtMaLopHocPhan = createTextField();
        txtMaLopHocPhan.setEditable(false);
        formPanel.add(txtMaLopHocPhan, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(createLabel("Tên LHP:"), gbc);
        gbc.gridx = 1;
        txtTenLopHocPhan = createTextField();
        formPanel.add(txtTenLopHocPhan, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(createLabel("Môn học:"), gbc);
        gbc.gridx = 1;
        cboMonHoc = createComboBox();
        formPanel.add(cboMonHoc, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        formPanel.add(createLabel("Giảng viên:"), gbc);
        gbc.gridx = 1;
        cboGiangVien = createComboBox();
        formPanel.add(cboGiangVien, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        formPanel.add(createLabel("Sĩ số tối đa:"), gbc);
        gbc.gridx = 1;
        txtSiSoToiDa = createTextField();
        formPanel.add(txtSiSoToiDa, gbc);

        gbc.gridx = 0; gbc.gridy = 6;
        formPanel.add(createLabel("Học kỳ:"), gbc);
        gbc.gridx = 1;
        cboHocKy = createComboBox();
        cboHocKy.addItem("2024-1");
        cboHocKy.addItem("2024-2");
        formPanel.add(cboHocKy, gbc);

        gbc.gridx = 0; gbc.gridy = 7;
        formPanel.add(createLabel("Năm học:"), gbc);
        gbc.gridx = 1;
        txtNamHoc = createTextField();
        txtNamHoc.setText("2024");
        formPanel.add(txtNamHoc, gbc);

        panelForm.add(formPanel);
        add(panelForm, BorderLayout.EAST);
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setForeground(textColor);
        return label;
    }

    private JTextField createTextField() {
        JTextField textField = new JTextField(20);
        textField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textField.setPreferredSize(new Dimension(200, 35));
        textField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return textField;
    }

    private JComboBox<String> createComboBox() {
        JComboBox<String> comboBox = new JComboBox<>();
        comboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        comboBox.setPreferredSize(new Dimension(200, 35));
        return comboBox;
    }

    private void taoPanelNut() {
        panelButton = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelButton.setBackground(backgroundColor);
        panelButton.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));

        btnThem = createButton("Thêm", primaryColor);
        btnSua = createButton("Sửa", primaryColor);
        btnXoa = createButton("Xóa", primaryColor);
        btnLamMoi = createButton("Làm mới", primaryColor);
        btnXemDiem = createButton("Xem điểm", primaryColor);

        panelButton.add(btnThem);
        panelButton.add(btnSua);
        panelButton.add(btnXoa);
        panelButton.add(btnLamMoi);
        panelButton.add(btnXemDiem);

        add(panelButton, BorderLayout.SOUTH);
    }

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                super.paintComponent(g);
                g2.dispose();
            }
        };
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(100, 35));

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });

        return button;
    }

    public JTable getTblLopHocPhan() {
        return tblLopHocPhan;
    }

    public DefaultTableModel getModelLopHocPhan() {
        return modelLopHocPhan;
    }

    public JTextField getTxtMaLopHocPhan() {
        return txtMaLopHocPhan;
    }

    public JTextField getTxtTenLopHocPhan() {
        return txtTenLopHocPhan;
    }

    public JComboBox<String> getCboMonHoc() {
        return cboMonHoc;
    }

    public JComboBox<String> getCboGiangVien() {
        return cboGiangVien;
    }

    public JTextField getTxtSiSoToiDa() {
        return txtSiSoToiDa;
    }

    public JTextField getTxtSearch() {
        return txtSearch;
    }

    public JComboBox<String> getCboHocKy() {
        return cboHocKy;
    }

    public JTextField getTxtNamHoc() {
        return txtNamHoc;
    }

    public void themSuKienThem(ActionListener listener) {
        btnThem.addActionListener(listener);
    }

    public void themSuKienSua(ActionListener listener) {
        btnSua.addActionListener(listener);
    }

    public void themSuKienXoa(ActionListener listener) {
        btnXoa.addActionListener(listener);
    }

    public void themSuKienLamMoi(ActionListener listener) {
        btnLamMoi.addActionListener(listener);
    }

    public void themSuKienChonDong(ListSelectionListener listener) {
        tblLopHocPhan.getSelectionModel().addListSelectionListener(listener);
    }

    public void themSuKienTimKiem(ActionListener listener) {
        txtSearch.addActionListener(listener);
    }

    public void themSuKienXemDiem(ActionListener listener) {
        btnXemDiem.addActionListener(listener);
    }

    public void lamMoiForm() {
        txtMaLopHocPhan.setText("");
        txtTenLopHocPhan.setText("");
        cboMonHoc.setSelectedIndex(0);
        cboGiangVien.setSelectedIndex(0);
        txtSiSoToiDa.setText("");
        cboHocKy.setSelectedIndex(0);
        txtNamHoc.setText("2024");
        tblLopHocPhan.clearSelection();
    }
}