package view;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import javax.swing.event.ListSelectionListener;

public class QuanLyGiangVienPanel extends JPanel {
    private JTable tblGiangVien;
    private DefaultTableModel modelGiangVien;
    private JTextField txtMaGiangVien, txtHoTen, txtEmail, txtSoDienThoai;
    private JComboBox<String> cboHocVi, cboHocHam, cboKhoa;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi;
    private JPanel panelForm, panelButton, panelSearch;
    private JTextField txtSearch;
    private JButton btnSearch;
    private Color primaryColor = new Color(33, 150, 243);
    private Color backgroundColor = new Color(245, 245, 245);
    private Color textColor = new Color(33, 33, 33);

    public QuanLyGiangVienPanel() {
        setLayout(new BorderLayout());
        setBackground(backgroundColor);
        taoBangGiangVien();
        taoPanelTimKiem();
        taoFormNhapLieu();
        taoPanelNut();
    }

    private void taoBangGiangVien() {
        String[] cot = {"Mã GV", "Họ tên", "Email", "Số điện thoại", "Học vị", "Học hàm", "Mã khoa"};
        modelGiangVien = new DefaultTableModel(cot, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblGiangVien = new JTable(modelGiangVien);
        
        JTableHeader header = tblGiangVien.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(primaryColor);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(header.getWidth(), 40));
        
        tblGiangVien.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tblGiangVien.setRowHeight(30);
        tblGiangVien.setSelectionBackground(new Color(33, 150, 243, 50));
        tblGiangVien.setSelectionForeground(textColor);
        tblGiangVien.setGridColor(new Color(200, 200, 200));
        tblGiangVien.setShowGrid(true);
        tblGiangVien.setIntercellSpacing(new Dimension(0, 0));
        
        JScrollPane scrollPane = new JScrollPane(tblGiangVien);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setBackground(backgroundColor);
        
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(backgroundColor);
        tablePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        add(tablePanel, BorderLayout.CENTER);
    }

    private void taoPanelTimKiem() {
        panelSearch = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelSearch.setBackground(backgroundColor);
        panelSearch.setBorder(BorderFactory.createEmptyBorder(20, 20, 0, 20));

        JLabel lblSearch = new JLabel("Tìm kiếm:");
        lblSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSearch.setForeground(textColor);
        panelSearch.add(lblSearch);

        txtSearch = new JTextField(20);
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setPreferredSize(new Dimension(200, 35));
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panelSearch.add(txtSearch);

        btnSearch = new JButton("Tìm kiếm");
        btnSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnSearch.setBackground(primaryColor);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFocusPainted(false);
        btnSearch.setBorderPainted(false);
        btnSearch.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSearch.setPreferredSize(new Dimension(100, 35));
        panelSearch.add(btnSearch);

        add(panelSearch, BorderLayout.NORTH);
    }

    private void taoFormNhapLieu() {
        panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(backgroundColor);
        panelForm.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel lblTitle = new JLabel("THÔNG TIN GIẢNG VIÊN");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(primaryColor);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 20, 0);
        formPanel.add(lblTitle, gbc);
        gbc.insets = new Insets(8, 8, 8, 8);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        formPanel.add(createLabel("Mã GV:"), gbc);
        gbc.gridx = 1;
        txtMaGiangVien = createTextField();
        txtMaGiangVien.setEditable(false);
        formPanel.add(txtMaGiangVien, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(createLabel("Họ tên:"), gbc);
        gbc.gridx = 1;
        txtHoTen = createTextField();
        formPanel.add(txtHoTen, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(createLabel("Email:"), gbc);
        gbc.gridx = 1;
        txtEmail = createTextField();
        formPanel.add(txtEmail, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        formPanel.add(createLabel("Số điện thoại:"), gbc);
        gbc.gridx = 1;
        txtSoDienThoai = createTextField();
        formPanel.add(txtSoDienThoai, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        formPanel.add(createLabel("Học vị:"), gbc);
        gbc.gridx = 1;
        cboHocVi = createComboBox();
        cboHocVi.addItem("-- Chọn học vị --");
        cboHocVi.addItem("Cử nhân");
        cboHocVi.addItem("Thạc sĩ");
        cboHocVi.addItem("Tiến sĩ");

        formPanel.add(cboHocVi, gbc);

        gbc.gridx = 0; gbc.gridy = 6;
        formPanel.add(createLabel("Học hàm:"), gbc);
        gbc.gridx = 1;
        cboHocHam = createComboBox();
        cboHocHam.addItem("-- Chọn học hàm --");
        cboHocHam.addItem("Không");
        cboHocHam.addItem("Phó Giáo sư");
        cboHocHam.addItem("Giáo sư");
        formPanel.add(cboHocHam, gbc);

        gbc.gridx = 0; gbc.gridy = 7;
        formPanel.add(createLabel("Khoa:"), gbc);
        gbc.gridx = 1;
        cboKhoa = createComboBox();
        cboKhoa.addItem("-- Chọn khoa --");
        formPanel.add(cboKhoa, gbc);

        panelForm.add(formPanel);
        add(panelForm, BorderLayout.EAST);
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setForeground(textColor);
        return label;
    }

    private JTextField createTextField() {
        JTextField textField = new JTextField(20);
        textField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textField.setPreferredSize(new Dimension(200, 35));
        textField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return textField;
    }

    private JComboBox<String> createComboBox() {
        JComboBox<String> comboBox = new JComboBox<>();
        comboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        comboBox.setPreferredSize(new Dimension(200, 35));
        return comboBox;
    }

    private void taoPanelNut() {
        panelButton = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelButton.setBackground(backgroundColor);
        panelButton.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        btnThem = createButton("Thêm", primaryColor);
        btnSua = createButton("Sửa", new Color(76, 175, 80));
        btnXoa = createButton("Xóa", new Color(244, 67, 54));
        btnLamMoi = createButton("Làm mới", new Color(158, 158, 158));

        panelButton.add(btnThem);
        panelButton.add(btnSua);
        panelButton.add(btnXoa);
        panelButton.add(btnLamMoi);

        add(panelButton, BorderLayout.SOUTH);
    }

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                super.paintComponent(g);
                g2.dispose();
            }
        };
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(100, 35));

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });

        return button;
    }

    // Getters và Setters
    public JTable getTblGiangVien() {
        return tblGiangVien;
    }

    public DefaultTableModel getModelGiangVien() {
        return modelGiangVien;
    }

    public JTextField getTxtMaGiangVien() {
        return txtMaGiangVien;
    }

    public JTextField getTxtHoTen() {
        return txtHoTen;
    }

    public JTextField getTxtEmail() {
        return txtEmail;
    }

    public JTextField getTxtSoDienThoai() {
        return txtSoDienThoai;
    }

    public JComboBox<String> getCboHocVi() {
        return cboHocVi;
    }

    public JComboBox<String> getCboHocHam() {
        return cboHocHam;
    }

    public JComboBox<String> getCboKhoa() {
        return cboKhoa;
    }

    public JTextField getTxtSearch() {
        return txtSearch;
    }

    public JButton getBtnSearch() {
        return btnSearch;
    }

    public void themSuKienThem(ActionListener listener) {
        btnThem.addActionListener(listener);
    }

    public void themSuKienSua(ActionListener listener) {
        btnSua.addActionListener(listener);
    }

    public void themSuKienXoa(ActionListener listener) {
        btnXoa.addActionListener(listener);
    }

    public void themSuKienLamMoi(ActionListener listener) {
        btnLamMoi.addActionListener(listener);
    }

    public void themSuKienChonDong(ListSelectionListener listener) {
        tblGiangVien.getSelectionModel().addListSelectionListener(listener);
    }

    public void themSuKienTimKiem(ActionListener listener) {
        txtSearch.addActionListener(listener);
    }

    public void lamMoiForm() {
        txtMaGiangVien.setText("");
        txtHoTen.setText("");
        txtEmail.setText("");
        txtSoDienThoai.setText("");
        cboHocVi.setSelectedIndex(0);
        cboHocHam.setSelectedIndex(0);
        cboKhoa.setSelectedIndex(0);
        txtSearch.setText("");
        tblGiangVien.clearSelection();
    }
} 