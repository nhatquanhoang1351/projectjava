package view;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import javax.swing.event.ListSelectionListener;

public class QuanLyMonHocPanel extends JPanel {
    private JTable tblMonHoc;
    private DefaultTableModel modelMonHoc;
    private JTextField txtMaMonHoc;
    private JTextField txtTenMonHoc;
    private JTextField txtSoTinChi;
    private JComboBox<String> cboKhoa;
    private JButton btnThem;
    private JButton btnSua;
    private JButton btnXoa;
    private JButton btnLamMoi;
    private JButton btnTimKiem;
    private JPanel panelForm, panelButton, panelSearch;
    private JTextField txtSearch;
    private Color primaryColor = new Color(33, 150, 243);
    private Color backgroundColor = new Color(245, 245, 245);
    private Color textColor = new Color(33, 33, 33);

    public QuanLyMonHocPanel() {
        setLayout(new BorderLayout());
        setBackground(backgroundColor);
        initComponents();
    }

    private void initComponents() {
        String[] columns = {"Mã môn học", "Tên môn học", "Số tín chỉ", "Khoa"};
        modelMonHoc = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblMonHoc = new JTable(modelMonHoc);
        
        JTableHeader header = tblMonHoc.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(primaryColor);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(header.getWidth(), 40));
        
        tblMonHoc.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tblMonHoc.setRowHeight(30);
        tblMonHoc.setSelectionBackground(new Color(33, 150, 243, 50));
        tblMonHoc.setSelectionForeground(textColor);
        tblMonHoc.setGridColor(new Color(200, 200, 200));
        tblMonHoc.setShowGrid(true);
        tblMonHoc.setIntercellSpacing(new Dimension(0, 0));
        
        JScrollPane scrollPane = new JScrollPane(tblMonHoc);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setBackground(backgroundColor);
        
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(backgroundColor);
        tablePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        add(tablePanel, BorderLayout.CENTER);

        panelSearch = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelSearch.setBackground(backgroundColor);
        panelSearch.setBorder(BorderFactory.createEmptyBorder(20, 20, 0, 20));

        JLabel lblSearch = new JLabel("Tìm kiếm:");
        lblSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSearch.setForeground(textColor);
        panelSearch.add(lblSearch);

        txtSearch = new JTextField(20);
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setPreferredSize(new Dimension(200, 35));
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panelSearch.add(txtSearch);

        btnTimKiem = new JButton("Tìm kiếm");
        btnTimKiem.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnTimKiem.setBackground(primaryColor);
        btnTimKiem.setForeground(Color.WHITE);
        btnTimKiem.setFocusPainted(false);
        btnTimKiem.setBorderPainted(false);
        btnTimKiem.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnTimKiem.setPreferredSize(new Dimension(100, 35));
        panelSearch.add(btnTimKiem);

        JButton btnHienTatCa = new JButton("Hiện tất cả");
        btnHienTatCa.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnHienTatCa.setBackground(new Color(76, 175, 80));
        btnHienTatCa.setForeground(Color.WHITE);
        btnHienTatCa.setFocusPainted(false);
        btnHienTatCa.setBorderPainted(false);
        btnHienTatCa.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnHienTatCa.setPreferredSize(new Dimension(100, 35));
        
        btnHienTatCa.addActionListener(e -> {
            txtSearch.setText("");
            for (ActionListener al : btnTimKiem.getActionListeners()) {
                al.actionPerformed(new ActionEvent(btnTimKiem, ActionEvent.ACTION_PERFORMED, null));
            }
        });
        panelSearch.add(btnHienTatCa);

        add(panelSearch, BorderLayout.NORTH);

        panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(backgroundColor);
        panelForm.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel lblTitle = new JLabel("THÔNG TIN MÔN HỌC");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(primaryColor);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 20, 0);
        formPanel.add(lblTitle, gbc);
        gbc.insets = new Insets(8, 8, 8, 8);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        formPanel.add(createLabel("Mã môn học:"), gbc);
        gbc.gridx = 1;
        txtMaMonHoc = createTextField();
        formPanel.add(txtMaMonHoc, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(createLabel("Tên môn học:"), gbc);
        gbc.gridx = 1;
        txtTenMonHoc = createTextField();
        formPanel.add(txtTenMonHoc, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(createLabel("Số tín chỉ:"), gbc);
        gbc.gridx = 1;
        txtSoTinChi = createTextField();
        formPanel.add(txtSoTinChi, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        formPanel.add(createLabel("Khoa:"), gbc);
        gbc.gridx = 1;
        cboKhoa = createComboBox();
        formPanel.add(cboKhoa, gbc);

        panelForm.add(formPanel);
        add(panelForm, BorderLayout.EAST);

        panelButton = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelButton.setBackground(backgroundColor);
        panelButton.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        btnThem = createButton("Thêm", primaryColor);
        btnSua = createButton("Sửa", new Color(76, 175, 80));
        btnXoa = createButton("Xóa", new Color(244, 67, 54));
        btnLamMoi = createButton("Làm mới", new Color(158, 158, 158));

        panelButton.add(btnThem);
        panelButton.add(btnSua);
        panelButton.add(btnXoa);
        panelButton.add(btnLamMoi);

        add(panelButton, BorderLayout.SOUTH);

        txtSearch.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    btnTimKiem.doClick();
                }
            }
        });
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setForeground(textColor);
        return label;
    }

    private JTextField createTextField() {
        JTextField textField = new JTextField(20);
        textField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textField.setPreferredSize(new Dimension(200, 35));
        textField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return textField;
    }

    private JComboBox<String> createComboBox() {
        JComboBox<String> comboBox = new JComboBox<>();
        comboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        comboBox.setPreferredSize(new Dimension(200, 35));
        return comboBox;
    }

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                super.paintComponent(g);
                g2.dispose();
            }
        };
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(100, 35));

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });

        return button;
    }

    // Getters
    public JTable getTblMonHoc() {
        return tblMonHoc;
    }

    public DefaultTableModel getModelMonHoc() {
        return modelMonHoc;
    }

    public JTextField getTxtMaMonHoc() {
        return txtMaMonHoc;
    }

    public JTextField getTxtTenMonHoc() {
        return txtTenMonHoc;
    }

    public JTextField getTxtSoTinChi() {
        return txtSoTinChi;
    }

    public JComboBox<String> getCboKhoa() {
        return cboKhoa;
    }

    public JTextField getTxtSearch() {
        return txtSearch;
    }

    public void themSuKienThem(ActionListener listener) {
        btnThem.addActionListener(listener);
    }

    public void themSuKienSua(ActionListener listener) {
        btnSua.addActionListener(listener);
    }

    public void themSuKienXoa(ActionListener listener) {
        btnXoa.addActionListener(listener);
    }

    public void themSuKienLamMoi(ActionListener listener) {
        btnLamMoi.addActionListener(listener);
    }

    public void themSuKienChonDong(ListSelectionListener listener) {
        tblMonHoc.getSelectionModel().addListSelectionListener(listener);
    }

    public void themSuKienTimKiem(ActionListener listener) {
        btnTimKiem.addActionListener(listener);
    }

    public void lamMoiForm() {
        txtMaMonHoc.setText("");
        txtTenMonHoc.setText("");
        txtSoTinChi.setText("");
        if (cboKhoa.getItemCount() > 0) {
            cboKhoa.setSelectedIndex(0);
        }
        txtSearch.setText("");
        tblMonHoc.clearSelection();
        
        txtMaMonHoc.setEditable(true);
        txtMaMonHoc.setBackground(Color.WHITE);
    }

    public void setFormForEdit() {
        txtMaMonHoc.setEditable(false);
        txtMaMonHoc.setBackground(new Color(240, 240, 240));
    }

    public boolean validateInput() {
        if (txtMaMonHoc.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập mã môn học!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            txtMaMonHoc.requestFocus();
            return false;
        }
        
        if (txtTenMonHoc.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập tên môn học!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            txtTenMonHoc.requestFocus();
            return false;
        }
        
        if (txtSoTinChi.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số tín chỉ!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            txtSoTinChi.requestFocus();
            return false;
        }
        
        try {
            int soTinChi = Integer.parseInt(txtSoTinChi.getText().trim());
            if (soTinChi <= 0) {
                JOptionPane.showMessageDialog(this, "Số tín chỉ phải lớn hơn 0!", 
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
                txtSoTinChi.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Số tín chỉ phải là số nguyên!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            txtSoTinChi.requestFocus();
            return false;
        }
        
        if (cboKhoa.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn khoa!", 
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            cboKhoa.requestFocus();
            return false;
        }
        
        return true;
    }

    public void hienThiThongBao(String message, String title, int messageType) {
        JOptionPane.showMessageDialog(this, message, title, messageType);
    }

    public void capNhatComboBoxKhoa(String[] danhSachKhoa) {
        cboKhoa.removeAllItems();
        for (String khoa : danhSachKhoa) {
            cboKhoa.addItem(khoa);
        }
    }

    public void xoaDuLieuTable() {
        modelMonHoc.setRowCount(0);
    }

    public void themDongVaoTable(Object[] rowData) {
        modelMonHoc.addRow(rowData);
    }

    public void capNhatDongTable(int row, Object[] rowData) {
        for (int i = 0; i < rowData.length; i++) {
            modelMonHoc.setValueAt(rowData[i], row, i);
        }
    }

    public void xoaDongTable(int row) {
        modelMonHoc.removeRow(row);
    }

    public int getSelectedRow() {
        return tblMonHoc.getSelectedRow();
    }

    public Object[] getSelectedRowData() {
        int row = getSelectedRow();
        if (row == -1) return null;
        
        Object[] rowData = new Object[modelMonHoc.getColumnCount()];
        for (int i = 0; i < modelMonHoc.getColumnCount(); i++) {
            rowData[i] = modelMonHoc.getValueAt(row, i);
        }
        return rowData;
    }

    public void setSelectedRow(int row) {
        if (row >= 0 && row < modelMonHoc.getRowCount()) {
            tblMonHoc.setRowSelectionInterval(row, row);
        }
    }

    public void scrollToRow(int row) {
        if (row >= 0 && row < modelMonHoc.getRowCount()) {
            tblMonHoc.scrollRectToVisible(tblMonHoc.getCellRect(row, 0, true));
        }
    }
}