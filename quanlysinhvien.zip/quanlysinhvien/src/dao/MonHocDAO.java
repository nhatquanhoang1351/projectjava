package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.MonHoc;

public class MonHocDAO extends BaseDAO {
    
    public MonHocDAO() {
        super();
        try {
            createTables();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public boolean themMonHoc(MonHoc mh) {
        String sql = "INSERT INTO mon_hoc (ma_Mon_Hoc, ten_Mon_Hoc, so_Tin_Chi, ma_Khoa) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, mh.getMaMonHoc());
            pstmt.setString(2, mh.getTenMonHoc());
            pstmt.setInt(3, mh.getSoTinChi());
            pstmt.setInt(4, mh.getMaKhoa());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean capNhatMonHoc(MonHoc mh) {
        String sql = "UPDATE mon_hoc SET ten_Mon_Hoc=?, so_Tin_Chi=?, ma_Khoa=? WHERE ma_Mon_Hoc=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, mh.getTenMonHoc());
            pstmt.setInt(2, mh.getSoTinChi());
            pstmt.setInt(3, mh.getMaKhoa());
            pstmt.setString(4, mh.getMaMonHoc());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean xoaMonHoc(String maMonHoc) {
        String sql = "DELETE FROM mon_hoc WHERE ma_Mon_Hoc=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, maMonHoc);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public MonHoc timMonHocTheoMa(String maMonHoc) {
        String sql = "SELECT * FROM mon_hoc WHERE ma_Mon_Hoc=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, maMonHoc);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return taoMonHocTuResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public List<MonHoc> layTatCaMonHoc() {
        List<MonHoc> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM mon_hoc";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoMonHocTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<MonHoc> timMonHocTheoTen(String ten) {
        List<MonHoc> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM mon_hoc WHERE ten_Mon_Hoc LIKE ?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, "%" + ten + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoMonHocTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<MonHoc> timMonHocTheoKhoa(int ma_Khoa) {
        List<MonHoc> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM mon_hoc WHERE ma_Khoa=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, ma_Khoa);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoMonHocTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    private MonHoc taoMonHocTuResultSet(ResultSet rs) throws SQLException {
        MonHoc mh = new MonHoc();
        mh.setMaMonHoc(rs.getString("ma_Mon_Hoc"));
        mh.setTenMonHoc(rs.getString("ten_Mon_Hoc"));
        mh.setSoTinChi(rs.getInt("so_Tin_Chi"));
        mh.setMaKhoa(rs.getInt("ma_Khoa"));
        return mh;
    }
} 