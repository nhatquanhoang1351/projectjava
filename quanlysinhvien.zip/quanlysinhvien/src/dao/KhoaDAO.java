package dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Khoa;

public class KhoaDAO extends BaseDAO {
    
    public KhoaDAO() {
        super();
        try {
            createTables();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public boolean themKhoa(Khoa khoa) {
        String sql = "INSERT INTO khoa (ten_Khoa, mo_Ta) VALUES (?, ?)";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, khoa.getTenKhoa());
            pstmt.setString(2, khoa.getMoTa());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean capNhatKhoa(Khoa khoa) {
        String sql = "UPDATE khoa SET ten_Khoa=?, mo_Ta=? WHERE ma_Khoa=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, khoa.getTenKhoa());
            pstmt.setString(2, khoa.getMoTa());
            pstmt.setInt(3, khoa.getMaKhoa());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean xoaKhoa(int ma_Khoa) {
        String sql = "DELETE FROM khoa WHERE ma_Khoa=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, ma_Khoa);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public Khoa timKhoaTheoMa(int ma_Khoa) {
        String sql = "SELECT * FROM khoa WHERE ma_Khoa=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, ma_Khoa);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return taoKhoaTuResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public List<Khoa> layTatCaKhoa() {
        List<Khoa> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM khoa";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoKhoaTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<Khoa> timKhoaTheoTen(String ten) {
        List<Khoa> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM khoa WHERE ten_Khoa LIKE ?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, "%" + ten + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoKhoaTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    private Khoa taoKhoaTuResultSet(ResultSet rs) throws SQLException {
        Khoa khoa = new Khoa();
        khoa.setMaKhoa(rs.getInt("ma_Khoa"));
        khoa.setTenKhoa(rs.getString("ten_Khoa"));
        khoa.setMoTa(rs.getString("mo_Ta"));
        return khoa;
    }
}