package dao;

import model.DangKyHocPhan;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DangKyHocPhanDAO extends BaseDAO {

    public DangKyHocPhanDAO() {
        super();
    }

    public boolean themDangKy(DangKyHocPhan dk) {
        String sql = "INSERT INTO dang_ky_hoc_phan (ma_sinh_vien, ma_lop_hoc_phan, ho_ten_sinh_vien, ngay_dang_ky, trang_thai) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, dk.getMaSinhVien());
            pstmt.setInt(2, dk.getMaLopHocPhan());
            pstmt.setString(3, dk.getHoTenSinhVien());
            pstmt.setTimestamp(4, dk.getNgayDangKy() != null ? Timestamp.valueOf(dk.getNgayDangKy()) : null);
            pstmt.setString(5, dk.getTrangThai());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean capNhatDangKy(DangKyHocPhan dk) {
        String sql = "UPDATE dang_ky_hoc_phan SET ma_sinh_vien = ?, ma_lop_hoc_phan = ?, ho_ten_sinh_vien = ?, trang_thai = ? WHERE ma_dang_ky = ?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, dk.getMaSinhVien());
            pstmt.setInt(2, dk.getMaLopHocPhan());
            pstmt.setString(3, dk.getHoTenSinhVien());
            pstmt.setString(4, dk.getTrangThai());
            pstmt.setInt(5, dk.getMaDangKy());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean capNhatTrangThaiDangKy(int maDangKy, String trangThai) {
        String sql = "UPDATE dang_ky_hoc_phan SET trang_thai = ? WHERE ma_dang_ky = ?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, trangThai);
            pstmt.setInt(2, maDangKy);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean xoaDangKy(int maDangKy) {
        String sql = "DELETE FROM dang_ky_hoc_phan WHERE ma_dang_ky = ?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maDangKy);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public DangKyHocPhan timDangKyTheoMa(int maDangKy) {
        String sql = "SELECT * FROM dang_ky_hoc_phan WHERE ma_dang_ky = ?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maDangKy);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return taoDangKyTuResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<DangKyHocPhan> layTatCaDangKy() {
        List<DangKyHocPhan> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM dang_ky_hoc_phan ORDER BY ngay_dang_ky DESC";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoDangKyTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }

    public List<DangKyHocPhan> timDangKyTheoTrangThai(String trangThai) {
        List<DangKyHocPhan> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM dang_ky_hoc_phan WHERE trang_thai LIKE ? ORDER BY ngay_dang_ky DESC";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, "%" + trangThai + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoDangKyTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }

    public List<DangKyHocPhan> timDangKyTheoLopHocPhan(int maLopHocPhan) {
        List<DangKyHocPhan> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM dang_ky_hoc_phan WHERE ma_lop_hoc_phan = ? ORDER BY ngay_dang_ky DESC";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maLopHocPhan);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoDangKyTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }

    private DangKyHocPhan taoDangKyTuResultSet(ResultSet rs) throws SQLException {
        DangKyHocPhan dk = new DangKyHocPhan();
        dk.setMaDangKy(rs.getInt("ma_dang_ky"));
        dk.setMaSinhVien(rs.getInt("ma_sinh_vien"));
        dk.setMaLopHocPhan(rs.getInt("ma_lop_hoc_phan"));
        dk.setHoTenSinhVien(rs.getString("ho_ten_sinh_vien"));
        Timestamp ts = rs.getTimestamp("ngay_dang_ky");
        if (ts != null) {
            dk.setNgayDangKy(ts.toLocalDateTime());
        }
        dk.setTrangThai(rs.getString("trang_thai"));
        return dk;
    }
}