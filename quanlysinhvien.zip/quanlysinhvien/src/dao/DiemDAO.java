package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Diem;

public class DiemDAO extends BaseDAO {
    
    public DiemDAO() {
        super();
        try {
            createTables();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public boolean themDiem(Diem diem) {
        String sql = "INSERT INTO diem (ma_sinh_vien, ma_lop_hoc_phan, diem_chuyen_can, diem_giua_ky, " +
                    "diem_cuoi_ky, diem_trung_binh) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, diem.getMaSinhVien());
            pstmt.setInt(2, diem.getMaLopHocPhan());
            pstmt.setFloat(3, diem.getDiemChuyenCan());
            pstmt.setFloat(4, diem.getDiemGiuaKy());
            pstmt.setFloat(5, diem.getDiemCuoiKy());
            pstmt.setFloat(6, diem.getDiemTrungBinh());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean capNhatDiem(Diem diem) {
        String sql = "UPDATE diem SET diem_chuyen_can=?, diem_giua_ky=?, diem_cuoi_ky=?, " +
                    "diem_trung_binh=? WHERE ma_diem=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setFloat(1, diem.getDiemChuyenCan());
            pstmt.setFloat(2, diem.getDiemGiuaKy());
            pstmt.setFloat(3, diem.getDiemCuoiKy());
            pstmt.setFloat(4, diem.getDiemTrungBinh());
            pstmt.setInt(5, diem.getMaDiem());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean xoaDiem(int maDiem) {
        String sql = "DELETE FROM diem WHERE ma_diem=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maDiem);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public Diem timDiemTheoMa(int maDiem) {
        String sql = "SELECT d.*, sv.ma_so, sv.ho_ten " +
                    "FROM diem d " +
                    "INNER JOIN sinh_vien sv ON d.ma_sinh_vien = sv.ma_sinh_vien " +
                    "WHERE d.ma_diem=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maDiem);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return taoDiemTuResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public List<Diem> layTatCaDiem() {
        List<Diem> danhSach = new ArrayList<>();
        String sql = "SELECT d.*, sv.ma_so, sv.ho_ten " +
                    "FROM diem d " +
                    "INNER JOIN sinh_vien sv ON d.ma_sinh_vien = sv.ma_sinh_vien";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoDiemTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<Diem> timDiemTheoSinhVien(int maSinhVien) {
        List<Diem> danhSach = new ArrayList<>();
        String sql = "SELECT d.*, sv.ma_so, sv.ho_ten " +
                    "FROM diem d " +
                    "INNER JOIN sinh_vien sv ON d.ma_sinh_vien = sv.ma_sinh_vien " +
                    "WHERE d.ma_sinh_vien=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maSinhVien);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoDiemTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<Diem> timDiemTheoLopHocPhan(int maLopHocPhan) {
        List<Diem> danhSach = new ArrayList<>();
        String sql = "SELECT d.*, sv.ma_so, sv.ho_ten " +
                    "FROM diem d " +
                    "INNER JOIN sinh_vien sv ON d.ma_sinh_vien = sv.ma_sinh_vien " +
                    "WHERE d.ma_lop_hoc_phan=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maLopHocPhan);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoDiemTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<Diem> timDiem(String tuKhoa) {
        List<Diem> danhSach = new ArrayList<>();
        String sql = "SELECT d.*, sv.ma_so, sv.ho_ten " +
                    "FROM diem d " +
                    "INNER JOIN sinh_vien sv ON d.ma_sinh_vien = sv.ma_sinh_vien " +
                    "WHERE sv.ma_so LIKE ? OR sv.ho_ten LIKE ? OR d.ma_lop_hoc_phan LIKE ?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            String pattern = "%" + tuKhoa + "%";
            pstmt.setString(1, pattern);
            pstmt.setString(2, pattern);
            pstmt.setString(3, pattern);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoDiemTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    private Diem taoDiemTuResultSet(ResultSet rs) throws SQLException {
        Diem diem = new Diem();
        diem.setMaDiem(rs.getInt("ma_diem"));
        diem.setMaSinhVien(rs.getInt("ma_sinh_vien"));
        diem.setMaLopHocPhan(rs.getInt("ma_lop_hoc_phan"));
        diem.setDiemChuyenCan(rs.getFloat("diem_chuyen_can"));
        diem.setDiemGiuaKy(rs.getFloat("diem_giua_ky"));
        diem.setDiemCuoiKy(rs.getFloat("diem_cuoi_ky"));
        diem.setDiemTrungBinh(rs.getFloat("diem_trung_binh"));
        diem.setMaSo(rs.getString("ma_so"));
        diem.setHoTen(rs.getString("ho_ten"));
        return diem;
    }
}