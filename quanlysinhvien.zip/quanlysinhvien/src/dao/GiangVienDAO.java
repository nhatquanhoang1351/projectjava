package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.GiangVien;

public class GiangVienDAO extends BaseDAO {
    
    public GiangVienDAO() {
        super();
        try {
            createTables();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public boolean themGiangVien(GiangVien gv) {
        String sql = "INSERT INTO giang_vien (ho_ten, email, so_dien_thoai, hoc_vi, hoc_ham, ma_khoa) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, gv.getHoTen());
            pstmt.setString(2, gv.getEmail());
            pstmt.setString(3, gv.getSoDienThoai());
            pstmt.setString(4, gv.getHocVi());
            pstmt.setString(5, gv.getHocHam());
            pstmt.setInt(6, gv.getMaKhoa());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean capNhatGiangVien(GiangVien gv) {
        String sql = "UPDATE giang_vien SET ho_ten=?, email=?, so_dien_thoai=?, hoc_vi=?, " +
                     "hoc_ham=?, ma_khoa=? WHERE ma_giang_vien=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, gv.getHoTen());
            pstmt.setString(2, gv.getEmail());
            pstmt.setString(3, gv.getSoDienThoai());
            pstmt.setString(4, gv.getHocVi());
            pstmt.setString(5, gv.getHocHam());
            pstmt.setInt(6, gv.getMaKhoa());
            pstmt.setInt(7, gv.getMaGiangVien());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean xoaGiangVien(int maGiangVien) {
        String sql = "DELETE FROM giang_vien WHERE ma_giang_vien=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maGiangVien);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public GiangVien timGiangVienTheoMa(int maGiangVien) {
        String sql = "SELECT * FROM giang_vien WHERE ma_giang_vien=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maGiangVien);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return taoGiangVienTuResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public List<GiangVien> layTatCaGiangVien() {
        List<GiangVien> danhSach = new ArrayList<>();
        String sql = "SELECT gv.*, k.ten_khoa " +
                     "FROM giang_vien gv " +
                     "LEFT JOIN khoa k ON gv.ma_khoa = k.ma_khoa " +
                     "ORDER BY gv.ma_giang_vien ASC";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoGiangVienTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<GiangVien> timGiangVienTheoTen(String ten) {
        List<GiangVien> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM giang_vien WHERE ho_ten LIKE ?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, "%" + ten + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoGiangVienTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<GiangVien> timGiangVienTheoKhoa(int maKhoa) {
        List<GiangVien> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM giang_vien WHERE ma_khoa=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maKhoa);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoGiangVienTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<GiangVien> timGiangVienTheoEmail(String email) {
        List<GiangVien> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM giang_vien WHERE email LIKE ?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, "%" + email + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoGiangVienTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<GiangVien> timGiangVienTheoHocVi(String hocVi) {
        List<GiangVien> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM giang_vien WHERE hoc_vi=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, hocVi);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoGiangVienTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<GiangVien> timGiangVienTheoHocHam(String hocHam) {
        List<GiangVien> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM giang_vien WHERE hoc_ham=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, hocHam);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoGiangVienTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    private GiangVien taoGiangVienTuResultSet(ResultSet rs) throws SQLException {
        GiangVien gv = new GiangVien();
        gv.setMaGiangVien(rs.getInt("ma_giang_vien"));
        gv.setHoTen(rs.getString("ho_ten"));
        gv.setEmail(rs.getString("email"));
        gv.setSoDienThoai(rs.getString("so_dien_thoai"));
        gv.setHocVi(rs.getString("hoc_vi"));
        gv.setHocHam(rs.getString("hoc_ham"));
        gv.setMaKhoa(rs.getInt("ma_khoa"));
        return gv;
    }
}