package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.LopHocPhan;

public class LopHocPhanDAO extends BaseDAO {
    
    public LopHocPhanDAO() {
        super();
        try {
            createTables();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public boolean themLopHocPhan(LopHocPhan lhp) {
        String sql = "INSERT INTO lop_hoc_phan (ma_mon_hoc, ten_lop_hoc_phan, hoc_ky, nam_hoc, ma_giang_vien, si_so) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, lhp.getMaMonHoc());
            pstmt.setString(2, lhp.getTenLopHocPhan());
            pstmt.setString(3, lhp.getHocKy());
            pstmt.setInt(4, lhp.getNamHoc());
            pstmt.setInt(5, lhp.getMaGiangVien());
            pstmt.setInt(6, lhp.getSiSo());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean capNhatLopHocPhan(LopHocPhan lhp) {
        String sql = "UPDATE lop_hoc_phan SET ma_mon_hoc=?, ten_lop_hoc_phan=?, hoc_ky=?, " +
                    "nam_hoc=?, ma_giang_vien=?, si_so=? WHERE ma_lop_hoc_phan=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, lhp.getMaMonHoc());
            pstmt.setString(2, lhp.getTenLopHocPhan());
            pstmt.setString(3, lhp.getHocKy());
            pstmt.setInt(4, lhp.getNamHoc());
            pstmt.setInt(5, lhp.getMaGiangVien());
            pstmt.setInt(6, lhp.getSiSo());
            pstmt.setInt(7, lhp.getMaLopHocPhan());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean xoaLopHocPhan(int maLopHocPhan) {
        String sql = "DELETE FROM lop_hoc_phan WHERE ma_lop_hoc_phan=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maLopHocPhan);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public LopHocPhan timLopHocPhanTheoMa(int maLopHocPhan) {
        String sql = "SELECT * FROM lop_hoc_phan WHERE ma_lop_hoc_phan=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maLopHocPhan);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return taoLopHocPhanTuResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public List<LopHocPhan> layTatCaLopHocPhan() {
        List<LopHocPhan> danhSach = new ArrayList<>();
        String sql = "SELECT lhp.*, mh.ten_mon_hoc, gv.ho_ten " +
                     "FROM lop_hoc_phan lhp " +
                     "LEFT JOIN mon_hoc mh ON lhp.ma_mon_hoc = mh.ma_mon_hoc " +
                     "LEFT JOIN giang_vien gv ON lhp.ma_giang_vien = gv.ma_giang_vien " +
                     "ORDER BY lhp.ma_lop_hoc_phan ASC";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoLopHocPhanTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<LopHocPhan> timLopHocPhanTheoTen(String ten) {
        List<LopHocPhan> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM lop_hoc_phan WHERE ten_lop_hoc_phan LIKE ?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, "%" + ten + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoLopHocPhanTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<LopHocPhan> timLopHocPhanTheoMonHoc(String maMonHoc) {
        List<LopHocPhan> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM lop_hoc_phan WHERE ma_mon_hoc=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, maMonHoc);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoLopHocPhanTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<LopHocPhan> timLopHocPhanTheoGiangVien(int maGiangVien) {
        List<LopHocPhan> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM lop_hoc_phan WHERE ma_giang_vien=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maGiangVien);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoLopHocPhanTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<LopHocPhan> timLopHocPhanTheoHocKy(String hocKy) {
        List<LopHocPhan> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM lop_hoc_phan WHERE hoc_ky=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, hocKy);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoLopHocPhanTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<LopHocPhan> timLopHocPhanTheoNamHoc(int namHoc) {
        List<LopHocPhan> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM lop_hoc_phan WHERE nam_hoc=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, namHoc);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoLopHocPhanTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public List<LopHocPhan> timLopHocPhanTheoHocKyVaNamHoc(String hocKy, int namHoc) {
        List<LopHocPhan> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM lop_hoc_phan WHERE hoc_ky=? AND nam_hoc=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, hocKy);
            pstmt.setInt(2, namHoc);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoLopHocPhanTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    public boolean capNhatSiSo(int maLopHocPhan, int siSo) {
        String sql = "UPDATE lop_hoc_phan SET si_so=? WHERE ma_lop_hoc_phan=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, siSo);
            pstmt.setInt(2, maLopHocPhan);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public List<LopHocPhan> layLopHocPhanTheoSinhVien(int maSinhVien, String namHoc, String hocKy) {
        List<LopHocPhan> danhSach = new ArrayList<>();
        String sql = "SELECT lhp.* FROM lop_hoc_phan lhp " +
                    "INNER JOIN dang_ky_hoc_phan dkhp ON lhp.ma_lop_hoc_phan = dkhp.ma_lop_hoc_phan " +
                    "WHERE dkhp.ma_sinh_vien = ? AND lhp.nam_hoc = ? AND lhp.hoc_ky = ?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maSinhVien);
            pstmt.setString(2, namHoc);
            pstmt.setString(3, hocKy);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoLopHocPhanTuResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
    
    private LopHocPhan taoLopHocPhanTuResultSet(ResultSet rs) throws SQLException {
        LopHocPhan lhp = new LopHocPhan();
        lhp.setMaLopHocPhan(rs.getInt("ma_lop_hoc_phan"));
        lhp.setMaMonHoc(rs.getString("ma_mon_hoc"));
        lhp.setTenLopHocPhan(rs.getString("ten_lop_hoc_phan"));
        lhp.setHocKy(rs.getString("hoc_ky"));
        lhp.setNamHoc(rs.getInt("nam_hoc"));
        lhp.setMaGiangVien(rs.getInt("ma_giang_vien"));
        lhp.setSiSo(rs.getInt("si_so"));
        return lhp;
    }
}