package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.SinhVien;

public class SinhVienDAO extends BaseDAO {
    
    public SinhVienDAO() {
        super();
        try {
            createTables();
        } catch (SQLException e) {
            System.err.println("Lỗi khi tạo bảng: " + e.getMessage());
        }
    }
    
    public boolean themSinhVien(SinhVien sv) {
        String sql = "INSERT INTO sinh_vien (ma_so, ho_ten, ngay_sinh, gioi_tinh, dia_chi, so_dien_thoai, email) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, sv.getMaSo());
            pstmt.setString(2, sv.getHoTen());
            pstmt.setString(3, sv.getNgaySinh());
            pstmt.setString(4, sv.getGioiTinh());
            pstmt.setString(5, sv.getDiaChi());
            pstmt.setString(6, sv.getSoDienThoai());
            pstmt.setString(7, sv.getEmail());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            if (e.getSQLState().equals("23000") && e.getMessage().contains("ma_so")) {
                System.err.println("Mã số sinh viên đã tồn tại!");
            } else {
                System.err.println("Lỗi khi thêm sinh viên: " + e.getMessage());
            }
            return false;
        }
    }
    
    public boolean capNhatSinhVien(SinhVien sv) {
        String sql = "UPDATE sinh_vien SET ma_so=?, ho_ten=?, ngay_sinh=?, " +
                    "gioi_tinh=?, dia_chi=?, so_dien_thoai=?, email=? WHERE ma_sinh_vien=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, sv.getMaSo());
            pstmt.setString(2, sv.getHoTen());
            pstmt.setString(3, sv.getNgaySinh());
            pstmt.setString(4, sv.getGioiTinh());
            pstmt.setString(5, sv.getDiaChi());
            pstmt.setString(6, sv.getSoDienThoai());
            pstmt.setString(7, sv.getEmail());
            pstmt.setInt(8, sv.getMaSinhVien());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            if (e.getSQLState().equals("23000") && e.getMessage().contains("ma_so")) {
                System.err.println("Mã số sinh viên đã tồn tại!");
            } else {
                System.err.println("Lỗi khi cập nhật sinh viên: " + e.getMessage());
            }
            return false;
        }
    }
    
    public boolean xoaSinhVien(int maSinhVien) {
        // Xóa các bản ghi liên quan trong dang_ky_hoc_phan và diem trước
        String deleteDangKy = "DELETE FROM dang_ky_hoc_phan WHERE ma_sinh_vien = ?";
        String deleteDiem = "DELETE FROM diem WHERE ma_sinh_vien = ?";
        String deleteSinhVien = "DELETE FROM sinh_vien WHERE ma_sinh_vien = ?";

        try (PreparedStatement pstmtDangKy = prepareStatement(deleteDangKy);
             PreparedStatement pstmtDiem = prepareStatement(deleteDiem);
             PreparedStatement pstmtSinhVien = prepareStatement(deleteSinhVien)) {

            // Xóa bản ghi trong dang_ky_hoc_phan
            pstmtDangKy.setInt(1, maSinhVien);
            pstmtDangKy.executeUpdate();

            // Xóa bản ghi trong diem
            pstmtDiem.setInt(1, maSinhVien);
            pstmtDiem.executeUpdate();

            // Xóa sinh viên
            pstmtSinhVien.setInt(1, maSinhVien);
            return pstmtSinhVien.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Lỗi khi xóa sinh viên: " + e.getMessage());
            return false;
        }
    }
    
    public SinhVien timSinhVienTheoMa(int maSinhVien) {
        String sql = "SELECT * FROM sinh_vien WHERE ma_sinh_vien=?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setInt(1, maSinhVien);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return taoSinhVienTuResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi tìm sinh viên: " + e.getMessage());
        }
        return null;
    }
    
    public List<SinhVien> layTatCaSinhVien() {
        List<SinhVien> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM sinh_vien";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                SinhVien sv = taoSinhVienTuResultSet(rs);
                danhSach.add(sv);
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi lấy danh sách sinh viên: " + e.getMessage());
        }
        return danhSach;
    }
    
    public List<SinhVien> timSinhVienTheoTen(String ten) {
        List<SinhVien> danhSach = new ArrayList<>();
        String sql = "SELECT * FROM sinh_vien WHERE ho_ten LIKE ?";
        try (PreparedStatement pstmt = prepareStatement(sql)) {
            pstmt.setString(1, "%" + ten + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                danhSach.add(taoSinhVienTuResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi tìm kiếm sinh viên theo tên: " + e.getMessage());
        }
        return danhSach;
    }
    
    private SinhVien taoSinhVienTuResultSet(ResultSet rs) throws SQLException {
        SinhVien sv = new SinhVien();
        sv.setMaSinhVien(rs.getInt("ma_sinh_vien"));
        sv.setMaSo(rs.getString("ma_so"));
        sv.setHoTen(rs.getString("ho_ten"));
        sv.setNgaySinh(rs.getString("ngay_sinh"));
        sv.setGioiTinh(rs.getString("gioi_tinh"));
        sv.setDiaChi(rs.getString("dia_chi"));
        sv.setSoDienThoai(rs.getString("so_dien_thoai"));
        sv.setEmail(rs.getString("email"));
        return sv;
    }
}