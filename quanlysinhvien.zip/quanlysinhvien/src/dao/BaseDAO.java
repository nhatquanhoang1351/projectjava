package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import model.KetNoiCSDL;

public class BaseDAO {
	protected Connection connection;

	public BaseDAO() {
		try {
			this.connection = KetNoiCSDL.layKetNoi();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void createTables() throws SQLException {
		createKhoaTable();
		createMonHocTable();
		createGiangVienTable();
		createSinhVienTable();
		createLopHocPhanTable();
		createDiemTable();
		createDangKyHocPhanTable();
	}

	private void createKhoaTable() throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS khoa (" 
				+ "maKhoa INT PRIMARY KEY AUTO_INCREMENT,"
				+ "tenKhoa VARCHAR(100) NOT NULL,"
				+ "moTa TEXT"
				+ ")";
		executeUpdate(sql);
	}

	private void createMonHocTable() throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS monhoc (" 
				+ "maMonHoc VARCHAR(20) PRIMARY KEY,"
				+ "tenMonHoc VARCHAR(100) NOT NULL," 
				+ "soTinChi INT NOT NULL," 
				+ "maKhoa INT,"
				+ "FOREIGN KEY (maKhoa) REFERENCES khoa(maKhoa)" 
				+ ")";
		executeUpdate(sql);
	}

	private void createGiangVienTable() throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS giangvien (" 
				+ "maGiangVien INT PRIMARY KEY AUTO_INCREMENT,"
				+ "hoTen VARCHAR(100) NOT NULL," 
				+ "email VARCHAR(100),"
				+ "soDienThoai VARCHAR(15)," 
				+ "hocVi VARCHAR(50)," 
				+ "hocHam VARCHAR(50),"
				+ "maKhoa INT," 
				+ "FOREIGN KEY (maKhoa) REFERENCES khoa(maKhoa)" 
				+ ")";
		executeUpdate(sql);
	}

	private void createSinhVienTable() throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS sinhvien (" 
				+ "maSinhVien INT PRIMARY KEY AUTO_INCREMENT,"
				+ "maSo VARCHAR(20) UNIQUE NOT NULL," 
				+ "hoTen VARCHAR(100) NOT NULL," 
				+ "tenLop VARCHAR(50),"
				+ "ngaySinh VARCHAR(20)," 
				+ "gioiTinh VARCHAR(10)," 
				+ "diaChi VARCHAR(200)," 
				+ "soDienThoai VARCHAR(15),"
				+ "email VARCHAR(100)" 
				+ ")";
		executeUpdate(sql);
	}

	private void createLopHocPhanTable() throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS lophocphan (" 
				+ "maLopHocPhan INT PRIMARY KEY AUTO_INCREMENT,"
				+ "maMonHoc VARCHAR(20)," 
				+ "tenLopHocPhan VARCHAR(100) NOT NULL," 
				+ "hocKy VARCHAR(20),"
				+ "namHoc INT," 
				+ "maGiangVien INT," 
				+ "siSo INT,"
				+ "FOREIGN KEY (maMonHoc) REFERENCES monhoc(maMonHoc),"
				+ "FOREIGN KEY (maGiangVien) REFERENCES giangvien(maGiangVien)" 
				+ ")";
		executeUpdate(sql);
	}

	private void createDiemTable() throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS diem (" 
				+ "maDiem INT PRIMARY KEY AUTO_INCREMENT," 
				+ "maSinhVien INT,"
				+ "maLopHocPhan INT," 
				+ "diemChuyenCan FLOAT," 
				+ "diemGiuaKy FLOAT," 
				+ "diemCuoiKy FLOAT,"
				+ "diemTrungBinh FLOAT," 
				+ "FOREIGN KEY (maSinhVien) REFERENCES sinhvien(maSinhVien),"
				+ "FOREIGN KEY (maLopHocPhan) REFERENCES lophocphan(maLopHocPhan)" 
				+ ")";
		executeUpdate(sql);
	}

	private void createDangKyHocPhanTable() throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS dangkyhocphan (" 
				+ "maDangKy INT PRIMARY KEY AUTO_INCREMENT,"
				+ "maSinhVien INT," 
				+ "maLopHocPhan INT," 
				+ "ngayDangKy DATETIME," 
				+ "trangThai VARCHAR(20),"
				+ "FOREIGN KEY (maSinhVien) REFERENCES sinhvien(maSinhVien),"
				+ "FOREIGN KEY (maLopHocPhan) REFERENCES lophocphan(maLopHocPhan)" 
				+ ")";
		executeUpdate(sql);
	}

	protected void executeUpdate(String sql) throws SQLException {
		try (Statement stmt = connection.createStatement()) {
			stmt.executeUpdate(sql);
		}
	}

	protected ResultSet executeQuery(String sql) throws SQLException {
		Statement stmt = connection.createStatement();
		return stmt.executeQuery(sql);
	}

	protected PreparedStatement prepareStatement(String sql) throws SQLException {
		return connection.prepareStatement(sql);
	}

	public void closeConnection() {
		try {
			if (connection != null && !connection.isClosed()) {
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}