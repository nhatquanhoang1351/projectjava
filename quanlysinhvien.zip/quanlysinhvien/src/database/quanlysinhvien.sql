-- Tạo cơ sở dữ liệu
CREATE DATABASE IF NOT EXISTS quanlysinhvien;
USE quanlysinhvien;

-- Tạo bảng Khoa
CREATE TABLE IF NOT EXISTS khoa (
    ma_khoa INT PRIMARY KEY AUTO_INCREMENT,
    ten_khoa VARCHAR(100) NOT NULL,
    mo_ta TEXT,
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tạo bảng Lớp
CREATE TABLE IF NOT EXISTS lop (
    ma_lop INT PRIMARY KEY AUTO_INCREMENT,
    ten_lop VARCHAR(50) NOT NULL,
    ma_khoa INT NOT NULL,
    si_so INT DEFAULT 0,
    nien_khoa VARCHAR(20) NOT NULL,
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (ma_khoa) REFERENCES khoa(ma_khoa)
);

-- Tạo bảng Sinh Viên
CREATE TABLE IF NOT EXISTS sinh_vien (
    ma_sinh_vien INT PRIMARY KEY AUTO_INCREMENT,
    ma_so VARCHAR(20) NOT NULL UNIQUE,
    ho_ten VARCHAR(100) NOT NULL,
    ma_lop INT NOT NULL,
    ngay_sinh DATE,
    gioi_tinh VARCHAR(10),
    dia_chi TEXT,
    so_dien_thoai VARCHAR(20),
    email VARCHAR(100),
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (ma_lop) REFERENCES lop(ma_lop)
);

-- Tạo bảng Môn Học
CREATE TABLE IF NOT EXISTS mon_hoc (
    ma_mon_hoc VARCHAR(20) PRIMARY KEY,
    ten_mon_hoc VARCHAR(100) NOT NULL,
    so_tin_chi INT NOT NULL,
    ma_khoa INT NOT NULL,
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (ma_khoa) REFERENCES khoa(ma_khoa)
);

-- Tạo bảng Điểm
CREATE TABLE IF NOT EXISTS diem (
    ma_diem INT PRIMARY KEY AUTO_INCREMENT,
    ma_sinh_vien INT NOT NULL,
    ma_mon_hoc VARCHAR(20) NOT NULL,
    diem_giua_ky FLOAT,
    diem_cuoi_ky FLOAT,
    diem_trung_binh FLOAT,
    hoc_ky VARCHAR(20) NOT NULL,
    nam_hoc INT NOT NULL,
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (ma_sinh_vien) REFERENCES sinh_vien(ma_sinh_vien),
    FOREIGN KEY (ma_mon_hoc) REFERENCES mon_hoc(ma_mon_hoc)
); 

CREATE TABLE IF NOT EXISTS giang_vien (
    ma_giang_vien INT PRIMARY KEY AUTO_INCREMENT,
    ho_ten VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    so_dien_thoai VARCHAR(20),
    hoc_vi VARCHAR(50),
    hoc_ham VARCHAR(50),
    ma_khoa INT,
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (ma_khoa) REFERENCES khoa(ma_khoa)
);