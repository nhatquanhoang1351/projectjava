package model;

public class LopHocPhan {
    private int maLopHocPhan;
    private String maMonHoc;
    private String tenLopHocPhan;
    private String hocKy;
    private int namHoc;
    private int maGiangVien;
    private int siSo;

    public LopHocPhan() {}

    public LopHocPhan(int maLopHocPhan, String maMonHoc, String tenLopHocPhan, String hocKy, int namHoc, int maGiangVien, int siSo) {
        this.maLopHocPhan = maLopHocPhan;
        this.maMonHoc = maMonHoc;
        this.tenLopHocPhan = tenLopHocPhan;
        this.hocKy = hocKy;
        this.namHoc = namHoc;
        this.maGiangVien = maGiangVien;
        this.siSo = siSo;
    }

    public int getMaLopHocPhan() {
        return maLopHocPhan;
    }

    public void setMaLopHocPhan(int maLopHocPhan) {
        this.maLopHocPhan = maLopHocPhan;
    }

    public String getMaMonHoc() {
        return maMonHoc;
    }

    public void setMaMonHoc(String maMonHoc) {
        this.maMonHoc = maMonHoc;
    }

    public String getTenLopHocPhan() {
        return tenLopHocPhan;
    }

    public void setTenLopHocPhan(String tenLopHocPhan) {
        this.tenLopHocPhan = tenLopHocPhan;
    }

    public String getHocKy() {
        return hocKy;
    }

    public void setHocKy(String hocKy) {
        this.hocKy = hocKy;
    }

    public int getNamHoc() {
        return namHoc;
    }

    public void setNamHoc(int namHoc) {
        this.namHoc = namHoc;
    }

    public int getMaGiangVien() {
        return maGiangVien;
    }

    public void setMaGiangVien(int maGiangVien) {
        this.maGiangVien = maGiangVien;
    }

    public int getSiSo() {
        return siSo;
    }

    public void setSiSo(int siSo) {
        this.siSo = siSo;
    }
} 