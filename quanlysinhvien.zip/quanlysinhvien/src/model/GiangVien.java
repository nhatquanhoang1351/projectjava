package model;

public class GiangVien {
    private int maGiangVien;
    private String hoTen;
    private String email;
    private String soDienThoai;
    private String hocVi;
    private String hocHam;
    private int maKhoa;

    public GiangVien() {}

    public GiangVien(int maGiangVien, String hoTen, String email, String soDienThoai, String hocVi, String hocHam, int maKhoa) {
        this.maGiangVien = maGiangVien;
        this.hoTen = hoTen;
        this.email = email;
        this.soDienThoai = soDienThoai;
        this.hocVi = hocVi;
        this.hocHam = hocHam;
        this.maKhoa = maKhoa;
    }

    public int getMaGiangVien() {
        return maGiangVien;
    }

    public void setMaGiangVien(int maGiangVien) {
        this.maGiangVien = maGiangVien;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public String getHocVi() {
        return hocVi;
    }

    public void setHocVi(String hocVi) {
        this.hocVi = hocVi;
    }

    public String getHocHam() {
        return hocHam;
    }

    public void setHocHam(String hocHam) {
        this.hocHam = hocHam;
    }

    public int getMaKhoa() {
        return maKhoa;
    }

    public void setMaKhoa(int maKhoa) {
        this.maKhoa = maKhoa;
    }
}

