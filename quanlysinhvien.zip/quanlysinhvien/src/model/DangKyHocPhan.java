package model;

import java.time.LocalDateTime;

public class DangKyHocPhan {
    private int maDangKy;
    private int maSinhVien;
    private int maLopHocPhan;
    private String hoTenSinhVien;
    private LocalDateTime ngayDangKy;
    private String trangThai; // "Đã đăng ký", "Hủy"

    public DangKyHocPhan() {
    }

    public DangKyHocPhan(int maDangKy, int maSinhVien, int maLopHocPhan, 
                        String hoTenSinhVien, LocalDateTime ngayDangKy, String trangThai) {
        this.maDangKy = maDangKy;
        this.maSinhVien = maSinhVien;
        this.maLopHocPhan = maLopHocPhan;
        this.hoTenSinhVien = hoTenSinhVien;
        this.ngayDangKy = ngayDangKy;
        this.trangThai = trangThai;
    }

    public int getMaDangKy() {
        return maDangKy;
    }

    public void setMaDangKy(int maDangKy) {
        this.maDangKy = maDangKy;
    }

    public int getMaSinhVien() {
        return maSinhVien;
    }

    public void setMaSinhVien(int maSinhVien) {
        this.maSinhVien = maSinhVien;
    }

    public int getMaLopHocPhan() {
        return maLopHocPhan;
    }

    public void setMaLopHocPhan(int maLopHocPhan) {
        this.maLopHocPhan = maLopHocPhan;
    }

    public String getHoTenSinhVien() {
        return hoTenSinhVien;
    }

    public void setHoTenSinhVien(String hoTenSinhVien) {
        this.hoTenSinhVien = hoTenSinhVien;
    }

    public LocalDateTime getNgayDangKy() {
        return ngayDangKy;
    }

    public void setNgayDangKy(LocalDateTime ngayDangKy) {
        this.ngayDangKy = ngayDangKy;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }
}