package model;

public class Diem {
    private int maDiem;
    private int maSinhVien;
    private int maLopHocPhan;
    private float diemChuyenCan;
    private float diemGiuaKy;
    private float diemCuoiKy;
    private float diemTrungBinh;
    private String maSo; // Thêm thuộc tính ma_so
    private String hoTen; // Thêm thuộc tính ho_ten

    public Diem() {
    }

    public Diem(int maDiem, int maSinhVien, int maLopHocPhan, float diemChuyenCan, float diemGiuaKy, float diemCuoiKy, float diemTrungBinh, String maSo, String hoTen) {
        this.maDiem = maDiem;
        this.maSinhVien = maSinhVien;
        this.maLopHocPhan = maLopHocPhan;
        this.diemChuyenCan = diemChuyenCan;
        this.diemGiuaKy = diemGiuaKy;
        this.diemCuoiKy = diemCuoiKy;
        this.diemTrungBinh = diemTrungBinh;
        this.maSo = maSo;
        this.hoTen = hoTen;
    }

    public int getMaDiem() {
        return maDiem;
    }

    public void setMaDiem(int maDiem) {
        this.maDiem = maDiem;
    }

    public int getMaSinhVien() {
        return maSinhVien;
    }

    public void setMaSinhVien(int maSinhVien) {
        this.maSinhVien = maSinhVien;
    }

    public int getMaLopHocPhan() {
        return maLopHocPhan;
    }

    public void setMaLopHocPhan(int maLopHocPhan) {
        this.maLopHocPhan = maLopHocPhan;
    }

    public float getDiemChuyenCan() {
        return diemChuyenCan;
    }

    public void setDiemChuyenCan(float diemChuyenCan) {
        this.diemChuyenCan = diemChuyenCan;
    }

    public float getDiemGiuaKy() {
        return diemGiuaKy;
    }

    public void setDiemGiuaKy(float diemGiuaKy) {
        this.diemGiuaKy = diemGiuaKy;
    }

    public float getDiemCuoiKy() {
        return diemCuoiKy;
    }

    public void setDiemCuoiKy(float diemCuoiKy) {
        this.diemCuoiKy = diemCuoiKy;
    }

    public float getDiemTrungBinh() {
        return diemTrungBinh;
    }

    public void setDiemTrungBinh(float diemTrungBinh) {
        this.diemTrungBinh = diemTrungBinh;
    }

    public String getMaSo() {
        return maSo;
    }

    public void setMaSo(String maSo) {
        this.maSo = maSo;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }
}